INSERT INTO dbdoap.role_ui_permission (ROLE_CODE,MENU_ID) VALUES
	 ('ROLE_ADMIN','adjustment'),
	 ('ROLE_ADMIN','api'),
	 ('ROLE_ADMIN','apigroup'),
	 ('ROLE_ADMIN','apipolicy'),
	 ('ROLE_ADMIN','apiResponse'),
	 ('ROLE_ADMIN','apitestbed'),
	 ('ROLE_ADMIN','app'),
	 ('ROLE_ADMIN','approval'),
	 ('ROLE_ADMIN','approvalline'),
	 ('ROLE_ADMIN','batchHistory');
INSERT INTO dbdoap.role_ui_permission (ROLE_CODE,MENU_ID) VALUES
	 ('ROLE_ADMIN','billing'),
	 ('ROLE_ADMIN','BillingDiscount'),
	 ('ROLE_ADMIN','billinghistory'),
	 ('ROLE_ADMIN','BillingPolicy'),
	 ('ROLE_ADMIN','certificate'),
	 ('ROLE_ADMIN','code'),
	 ('ROLE_ADMIN','commit'),
	 ('ROLE_ADMIN','commitdeploy'),
	 ('ROLE_ADMIN','content'),
	 ('ROLE_ADMIN','dashboard');
INSERT INTO dbdoap.role_ui_permission (ROLE_CODE,MENU_ID) VALUES
	 ('ROLE_ADMIN','deploy'),
	 ('ROLE_ADMIN','invoice.'),
	 ('ROLE_ADMIN','log'),
	 ('ROLE_ADMIN','organization'),
	 ('ROLE_ADMIN','organizationToken'),
	 ('ROLE_ADMIN','pending'),
	 ('ROLE_ADMIN','podInfo'),
	 ('ROLE_ADMIN','podStatus'),
	 ('ROLE_ADMIN','portallog'),
	 ('ROLE_ADMIN','progress');
INSERT INTO dbdoap.role_ui_permission (ROLE_CODE,MENU_ID) VALUES
	 ('ROLE_ADMIN','regularManage'),
	 ('ROLE_ADMIN','request'),
	 ('ROLE_ADMIN','rolePermission'),
	 ('ROLE_ADMIN','statistics'),
	 ('ROLE_ADMIN','system'),
	 ('ROLE_ADMIN','template'),
	 ('ROLE_ADMIN','terms'),
	 ('ROLE_ADMIN','user'),
	 ('ROLE_OFFER_MANAGER','api'),
	 ('ROLE_OFFER_MANAGER','apigroup');
INSERT INTO dbdoap.role_ui_permission (ROLE_CODE,MENU_ID) VALUES
	 ('ROLE_OFFER_MANAGER','apipolicy'),
	 ('ROLE_OFFER_MANAGER','apiResponse'),
	 ('ROLE_OFFER_MANAGER','apitestbed'),
	 ('ROLE_OFFER_MANAGER','app'),
	 ('ROLE_OFFER_MANAGER','approval'),
	 ('ROLE_OFFER_MANAGER','approvalline'),
	 ('ROLE_OFFER_MANAGER','dashboard'),
	 ('ROLE_OFFER_MANAGER','eimsapi'),
	 ('ROLE_OFFER_MANAGER','organization'),
	 ('ROLE_OFFER_MANAGER','pending');
INSERT INTO dbdoap.role_ui_permission (ROLE_CODE,MENU_ID) VALUES
	 ('ROLE_OFFER_MANAGER','progress'),
	 ('ROLE_OFFER_MANAGER','request'),
	 ('ROLE_OFFER_MANAGER','statistics'),
	 ('ROLE_OFFER_MANAGER','user'),
	 ('ROLE_OFFER_MEMBER','api'),
	 ('ROLE_OFFER_MEMBER','apigroup'),
	 ('ROLE_OFFER_MEMBER','apipolicy'),
	 ('ROLE_OFFER_MEMBER','apiResponse'),
	 ('ROLE_OFFER_MEMBER','apitestbed'),
	 ('ROLE_OFFER_MEMBER','app');
INSERT INTO dbdoap.role_ui_permission (ROLE_CODE,MENU_ID) VALUES
	 ('ROLE_OFFER_MEMBER','eimsapi'),
	 ('ROLE_USER_MEMBER','api');
