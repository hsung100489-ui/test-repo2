-- dbpoac.access definition

CREATE TABLE `access` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `mode` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_access_s` (`user_id`,`repo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.access_token definition

CREATE TABLE `access_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `token_hash` varchar(255) DEFAULT NULL,
  `token_salt` varchar(255) DEFAULT NULL,
  `token_last_eight` varchar(255) DEFAULT NULL,
  `scope` varchar(255) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_access_token_token_hash` (`token_hash`),
  KEY `IDX_access_token_updated_unix` (`updated_unix`),
  KEY `IDX_access_token_uid` (`uid`),
  KEY `IDX_access_token_token_last_eight` (`token_last_eight`),
  KEY `IDX_access_token_created_unix` (`created_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.`action` definition

CREATE TABLE `action` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `op_type` int(11) DEFAULT NULL,
  `act_user_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `comment_id` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(1) NOT NULL DEFAULT 0,
  `ref_name` varchar(255) DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `content` text DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_action_user_id` (`user_id`),
  KEY `IDX_action_comment_id` (`comment_id`),
  KEY `IDX_action_au_r_c_u_d` (`act_user_id`,`repo_id`,`created_unix`,`user_id`,`is_deleted`),
  KEY `IDX_action_r_u_d` (`repo_id`,`user_id`,`is_deleted`),
  KEY `IDX_action_c_u_d` (`created_unix`,`user_id`,`is_deleted`),
  KEY `IDX_action_c_u` (`user_id`,`is_deleted`),
  KEY `IDX_action_au_c_u` (`act_user_id`,`created_unix`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3445 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_artifact definition

CREATE TABLE `action_artifact` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `run_id` bigint(20) DEFAULT NULL,
  `runner_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `commit_sha` varchar(255) DEFAULT NULL,
  `storage_path` varchar(255) DEFAULT NULL,
  `file_size` bigint(20) DEFAULT NULL,
  `file_compressed_size` bigint(20) DEFAULT NULL,
  `content_encoding` varchar(255) DEFAULT NULL,
  `artifact_path` varchar(255) DEFAULT NULL,
  `artifact_name` varchar(255) DEFAULT NULL,
  `status` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `expired_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_artifact_runid_name_path` (`run_id`,`artifact_path`,`artifact_name`),
  KEY `IDX_action_artifact_artifact_path` (`artifact_path`),
  KEY `IDX_action_artifact_artifact_name` (`artifact_name`),
  KEY `IDX_action_artifact_status` (`status`),
  KEY `IDX_action_artifact_updated_unix` (`updated_unix`),
  KEY `IDX_action_artifact_expired_unix` (`expired_unix`),
  KEY `IDX_action_artifact_run_id` (`run_id`),
  KEY `IDX_action_artifact_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_run definition

CREATE TABLE `action_run` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `workflow_id` varchar(255) DEFAULT NULL,
  `index` bigint(20) DEFAULT NULL,
  `trigger_user_id` bigint(20) DEFAULT NULL,
  `schedule_id` bigint(20) DEFAULT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `commit_sha` varchar(255) DEFAULT NULL,
  `is_fork_pull_request` tinyint(1) DEFAULT NULL,
  `need_approval` tinyint(1) DEFAULT NULL,
  `approved_by` bigint(20) DEFAULT NULL,
  `event` varchar(255) DEFAULT NULL,
  `event_payload` longtext DEFAULT NULL,
  `trigger_event` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `version` int(11) DEFAULT 0,
  `started` bigint(20) DEFAULT NULL,
  `stopped` bigint(20) DEFAULT NULL,
  `previous_duration` bigint(20) DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_run_repo_index` (`repo_id`,`index`),
  KEY `IDX_action_run_owner_id` (`owner_id`),
  KEY `IDX_action_run_index` (`index`),
  KEY `IDX_action_run_trigger_user_id` (`trigger_user_id`),
  KEY `IDX_action_run_ref` (`ref`),
  KEY `IDX_action_run_approved_by` (`approved_by`),
  KEY `IDX_action_run_status` (`status`),
  KEY `IDX_action_run_repo_id` (`repo_id`),
  KEY `IDX_action_run_workflow_id` (`workflow_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2029 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_run_index definition

CREATE TABLE `action_run_index` (
  `group_id` bigint(20) NOT NULL,
  `max_index` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  KEY `IDX_action_run_index_max_index` (`max_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_run_job definition

CREATE TABLE `action_run_job` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `run_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `commit_sha` varchar(255) DEFAULT NULL,
  `is_fork_pull_request` tinyint(1) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `attempt` bigint(20) DEFAULT NULL,
  `workflow_payload` blob DEFAULT NULL,
  `job_id` varchar(255) DEFAULT NULL,
  `needs` text DEFAULT NULL,
  `runs_on` text DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `started` bigint(20) DEFAULT NULL,
  `stopped` bigint(20) DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_action_run_job_updated` (`updated`),
  KEY `IDX_action_run_job_run_id` (`run_id`),
  KEY `IDX_action_run_job_repo_id` (`repo_id`),
  KEY `IDX_action_run_job_owner_id` (`owner_id`),
  KEY `IDX_action_run_job_commit_sha` (`commit_sha`),
  KEY `IDX_action_run_job_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2060 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_runner definition

CREATE TABLE `action_runner` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` char(36) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `version` varchar(64) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `base` int(11) DEFAULT NULL,
  `repo_range` varchar(255) DEFAULT NULL,
  `token_hash` varchar(255) DEFAULT NULL,
  `token_salt` varchar(255) DEFAULT NULL,
  `last_online` bigint(20) DEFAULT NULL,
  `last_active` bigint(20) DEFAULT NULL,
  `agent_labels` text DEFAULT NULL,
  `ephemeral` tinyint(1) NOT NULL DEFAULT 0,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  `deleted` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_runner_token_hash` (`token_hash`),
  UNIQUE KEY `UQE_action_runner_uuid` (`uuid`),
  KEY `IDX_action_runner_owner_id` (`owner_id`),
  KEY `IDX_action_runner_repo_id` (`repo_id`),
  KEY `IDX_action_runner_last_online` (`last_online`),
  KEY `IDX_action_runner_last_active` (`last_active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_runner_token definition

CREATE TABLE `action_runner_token` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  `deleted` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_runner_token_token` (`token`),
  KEY `IDX_action_runner_token_owner_id` (`owner_id`),
  KEY `IDX_action_runner_token_repo_id` (`repo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_schedule definition

CREATE TABLE `action_schedule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `specs` text DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `workflow_id` varchar(255) DEFAULT NULL,
  `trigger_user_id` bigint(20) DEFAULT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `commit_sha` varchar(255) DEFAULT NULL,
  `event` varchar(255) DEFAULT NULL,
  `event_payload` longtext DEFAULT NULL,
  `content` blob DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_action_schedule_repo_id` (`repo_id`),
  KEY `IDX_action_schedule_owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_schedule_spec definition

CREATE TABLE `action_schedule_spec` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `schedule_id` bigint(20) DEFAULT NULL,
  `next` bigint(20) DEFAULT NULL,
  `prev` bigint(20) DEFAULT NULL,
  `spec` varchar(255) DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_action_schedule_spec_repo_id` (`repo_id`),
  KEY `IDX_action_schedule_spec_schedule_id` (`schedule_id`),
  KEY `IDX_action_schedule_spec_next` (`next`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_task definition

CREATE TABLE `action_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `job_id` bigint(20) DEFAULT NULL,
  `attempt` bigint(20) DEFAULT NULL,
  `runner_id` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `started` bigint(20) DEFAULT NULL,
  `stopped` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `commit_sha` varchar(255) DEFAULT NULL,
  `is_fork_pull_request` tinyint(1) DEFAULT NULL,
  `token_hash` varchar(255) DEFAULT NULL,
  `token_salt` varchar(255) DEFAULT NULL,
  `token_last_eight` varchar(255) DEFAULT NULL,
  `log_filename` varchar(255) DEFAULT NULL,
  `log_in_storage` tinyint(1) DEFAULT NULL,
  `log_length` bigint(20) DEFAULT NULL,
  `log_size` bigint(20) DEFAULT NULL,
  `log_indexes` longblob DEFAULT NULL,
  `log_expired` tinyint(1) DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_task_token_hash` (`token_hash`),
  KEY `IDX_action_task_status` (`status`),
  KEY `IDX_action_task_started` (`started`),
  KEY `IDX_action_task_stopped_log_expired` (`stopped`,`log_expired`),
  KEY `IDX_action_task_owner_id` (`owner_id`),
  KEY `IDX_action_task_commit_sha` (`commit_sha`),
  KEY `IDX_action_task_token_last_eight` (`token_last_eight`),
  KEY `IDX_action_task_runner_id` (`runner_id`),
  KEY `IDX_action_task_repo_id` (`repo_id`),
  KEY `IDX_action_task_updated` (`updated`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_task_output definition

CREATE TABLE `action_task_output` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `task_id` bigint(20) DEFAULT NULL,
  `output_key` varchar(255) DEFAULT NULL,
  `output_value` mediumtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_task_output_task_id_output_key` (`task_id`,`output_key`),
  KEY `IDX_action_task_output_task_id` (`task_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_task_step definition

CREATE TABLE `action_task_step` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `task_id` bigint(20) DEFAULT NULL,
  `index` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `log_index` bigint(20) DEFAULT NULL,
  `log_length` bigint(20) DEFAULT NULL,
  `started` bigint(20) DEFAULT NULL,
  `stopped` bigint(20) DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_task_step_task_index` (`task_id`,`index`),
  KEY `IDX_action_task_step_index` (`index`),
  KEY `IDX_action_task_step_repo_id` (`repo_id`),
  KEY `IDX_action_task_step_status` (`status`),
  KEY `IDX_action_task_step_task_id` (`task_id`)
) ENGINE=InnoDB AUTO_INCREMENT=518 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_tasks_version definition

CREATE TABLE `action_tasks_version` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `version` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_tasks_version_owner_repo` (`owner_id`,`repo_id`),
  KEY `IDX_action_tasks_version_repo_id` (`repo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.action_variable definition

CREATE TABLE `action_variable` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `data` longtext NOT NULL,
  `description` text DEFAULT NULL,
  `created_unix` bigint(20) NOT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_action_variable_owner_repo_name` (`owner_id`,`repo_id`,`name`),
  KEY `IDX_action_variable_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.app_state definition

CREATE TABLE `app_state` (
  `id` varchar(200) NOT NULL,
  `revision` bigint(20) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.attachment definition

CREATE TABLE `attachment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(40) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  `release_id` bigint(20) DEFAULT NULL,
  `uploader_id` bigint(20) DEFAULT 0,
  `comment_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `download_count` bigint(20) DEFAULT 0,
  `size` bigint(20) DEFAULT 0,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_attachment_uuid` (`uuid`),
  KEY `IDX_attachment_release_id` (`release_id`),
  KEY `IDX_attachment_uploader_id` (`uploader_id`),
  KEY `IDX_attachment_comment_id` (`comment_id`),
  KEY `IDX_attachment_repo_id` (`repo_id`),
  KEY `IDX_attachment_issue_id` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.auth_token definition

CREATE TABLE `auth_token` (
  `id` varchar(255) NOT NULL,
  `token_hash` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `expires_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_auth_token_user_id` (`user_id`),
  KEY `IDX_auth_token_expires_unix` (`expires_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.badge definition

CREATE TABLE `badge` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `image_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_badge_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.branch definition

CREATE TABLE `branch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `commit_id` varchar(255) DEFAULT NULL,
  `commit_message` text DEFAULT NULL,
  `pusher_id` bigint(20) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  `deleted_by_id` bigint(20) DEFAULT NULL,
  `deleted_unix` bigint(20) DEFAULT NULL,
  `commit_time` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_branch_s` (`repo_id`,`name`),
  KEY `IDX_branch_is_deleted` (`is_deleted`),
  KEY `IDX_branch_deleted_unix` (`deleted_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.collaboration definition

CREATE TABLE `collaboration` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `mode` int(11) NOT NULL DEFAULT 2,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_collaboration_s` (`repo_id`,`user_id`),
  KEY `IDX_collaboration_created_unix` (`created_unix`),
  KEY `IDX_collaboration_updated_unix` (`updated_unix`),
  KEY `IDX_collaboration_repo_id` (`repo_id`),
  KEY `IDX_collaboration_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.comment definition

CREATE TABLE `comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `poster_id` bigint(20) DEFAULT NULL,
  `original_author` varchar(255) DEFAULT NULL,
  `original_author_id` bigint(20) DEFAULT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  `label_id` bigint(20) DEFAULT NULL,
  `old_project_id` bigint(20) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `old_milestone_id` bigint(20) DEFAULT NULL,
  `milestone_id` bigint(20) DEFAULT NULL,
  `time_id` bigint(20) DEFAULT NULL,
  `assignee_id` bigint(20) DEFAULT NULL,
  `removed_assignee` tinyint(1) DEFAULT NULL,
  `assignee_team_id` bigint(20) NOT NULL DEFAULT 0,
  `resolve_doer_id` bigint(20) DEFAULT NULL,
  `old_title` varchar(255) DEFAULT NULL,
  `new_title` varchar(255) DEFAULT NULL,
  `old_ref` varchar(255) DEFAULT NULL,
  `new_ref` varchar(255) DEFAULT NULL,
  `dependent_issue_id` bigint(20) DEFAULT NULL,
  `commit_id` bigint(20) DEFAULT NULL,
  `line` bigint(20) DEFAULT NULL,
  `tree_path` varchar(4000) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `content_version` int(11) NOT NULL DEFAULT 0,
  `patch` longtext DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `commit_sha` varchar(64) DEFAULT NULL,
  `review_id` bigint(20) DEFAULT NULL,
  `invalidated` tinyint(1) DEFAULT NULL,
  `ref_repo_id` bigint(20) DEFAULT NULL,
  `ref_issue_id` bigint(20) DEFAULT NULL,
  `ref_comment_id` bigint(20) DEFAULT NULL,
  `ref_action` smallint(6) DEFAULT NULL,
  `ref_is_pull` tinyint(1) DEFAULT NULL,
  `comment_meta_data` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_comment_type` (`type`),
  KEY `IDX_comment_issue_id` (`issue_id`),
  KEY `IDX_comment_dependent_issue_id` (`dependent_issue_id`),
  KEY `IDX_comment_updated_unix` (`updated_unix`),
  KEY `IDX_comment_poster_id` (`poster_id`),
  KEY `IDX_comment_created_unix` (`created_unix`),
  KEY `IDX_comment_review_id` (`review_id`),
  KEY `IDX_comment_ref_repo_id` (`ref_repo_id`),
  KEY `IDX_comment_ref_issue_id` (`ref_issue_id`),
  KEY `IDX_comment_ref_comment_id` (`ref_comment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.commit_status definition

CREATE TABLE `commit_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `index` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `state` varchar(7) NOT NULL,
  `sha` varchar(64) NOT NULL,
  `target_url` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `context_hash` varchar(64) DEFAULT NULL,
  `context` text DEFAULT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_commit_status_repo_sha_index` (`index`,`repo_id`,`sha`),
  KEY `IDX_commit_status_repo_id` (`repo_id`),
  KEY `IDX_commit_status_sha` (`sha`),
  KEY `IDX_commit_status_context_hash` (`context_hash`),
  KEY `IDX_commit_status_created_unix` (`created_unix`),
  KEY `IDX_commit_status_updated_unix` (`updated_unix`),
  KEY `IDX_commit_status_index` (`index`)
) ENGINE=InnoDB AUTO_INCREMENT=348 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.commit_status_index definition

CREATE TABLE `commit_status_index` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `sha` varchar(255) DEFAULT NULL,
  `max_index` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_commit_status_index_repo_sha` (`repo_id`,`sha`),
  KEY `IDX_commit_status_index_max_index` (`max_index`)
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.commit_status_summary definition

CREATE TABLE `commit_status_summary` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `sha` varchar(64) NOT NULL,
  `state` varchar(7) NOT NULL,
  `target_url` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_commit_status_summary_repo_id_sha` (`repo_id`,`sha`),
  KEY `IDX_commit_status_summary_repo_id` (`repo_id`),
  KEY `IDX_commit_status_summary_sha` (`sha`)
) ENGINE=InnoDB AUTO_INCREMENT=347 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.dbfs_data definition

CREATE TABLE `dbfs_data` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `revision` bigint(20) NOT NULL,
  `meta_id` bigint(20) NOT NULL,
  `blob_offset` bigint(20) NOT NULL,
  `blob_size` bigint(20) NOT NULL,
  `blob_data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_dbfs_data_meta_offset` (`meta_id`,`blob_offset`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.dbfs_meta definition

CREATE TABLE `dbfs_meta` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `full_path` varchar(500) NOT NULL,
  `block_size` bigint(20) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `create_timestamp` bigint(20) NOT NULL,
  `modify_timestamp` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_dbfs_meta_full_path` (`full_path`)
) ENGINE=InnoDB AUTO_INCREMENT=230 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.deploy_key definition

CREATE TABLE `deploy_key` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `key_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `fingerprint` varchar(255) DEFAULT NULL,
  `mode` int(11) NOT NULL DEFAULT 1,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_deploy_key_s` (`key_id`,`repo_id`),
  KEY `IDX_deploy_key_key_id` (`key_id`),
  KEY `IDX_deploy_key_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.email_address definition

CREATE TABLE `email_address` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `email` varchar(255) NOT NULL,
  `lower_email` varchar(255) NOT NULL,
  `is_activated` tinyint(1) DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_email_address_email` (`email`),
  UNIQUE KEY `UQE_email_address_lower_email` (`lower_email`),
  KEY `IDX_email_address_uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.email_hash definition

CREATE TABLE `email_hash` (
  `hash` varchar(32) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`hash`),
  UNIQUE KEY `UQE_email_hash_email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.external_login_user definition

CREATE TABLE `external_login_user` (
  `external_id` varchar(255) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `login_source_id` bigint(20) NOT NULL,
  `raw_data` text DEFAULT NULL,
  `provider` varchar(25) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `nick_name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `avatar_url` text DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `access_token` text DEFAULT NULL,
  `access_token_secret` text DEFAULT NULL,
  `refresh_token` text DEFAULT NULL,
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`external_id`,`login_source_id`),
  KEY `IDX_external_login_user_user_id` (`user_id`),
  KEY `IDX_external_login_user_provider` (`provider`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.follow definition

CREATE TABLE `follow` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `follow_id` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_follow_follow` (`user_id`,`follow_id`),
  KEY `IDX_follow_created_unix` (`created_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.gpg_key definition

CREATE TABLE `gpg_key` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) NOT NULL,
  `key_id` char(16) NOT NULL,
  `primary_key_id` char(16) DEFAULT NULL,
  `content` mediumtext NOT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `expired_unix` bigint(20) DEFAULT NULL,
  `added_unix` bigint(20) DEFAULT NULL,
  `emails` text DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  `can_sign` tinyint(1) DEFAULT NULL,
  `can_encrypt_comms` tinyint(1) DEFAULT NULL,
  `can_encrypt_storage` tinyint(1) DEFAULT NULL,
  `can_certify` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_gpg_key_owner_id` (`owner_id`),
  KEY `IDX_gpg_key_key_id` (`key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.gpg_key_import definition

CREATE TABLE `gpg_key_import` (
  `key_id` char(16) NOT NULL,
  `content` mediumtext NOT NULL,
  PRIMARY KEY (`key_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.hook_task definition

CREATE TABLE `hook_task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `hook_id` bigint(20) DEFAULT NULL,
  `uuid` varchar(255) DEFAULT NULL,
  `payload_content` longtext DEFAULT NULL,
  `payload_version` int(11) DEFAULT 1,
  `event_type` varchar(255) DEFAULT NULL,
  `is_delivered` tinyint(1) DEFAULT NULL,
  `delivered` bigint(20) DEFAULT NULL,
  `is_succeed` tinyint(1) DEFAULT NULL,
  `request_content` longtext DEFAULT NULL,
  `response_content` longtext DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_hook_task_uuid` (`uuid`),
  KEY `IDX_hook_task_hook_id` (`hook_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue definition

CREATE TABLE `issue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `index` bigint(20) DEFAULT NULL,
  `poster_id` bigint(20) DEFAULT NULL,
  `original_author` varchar(255) DEFAULT NULL,
  `original_author_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` longtext DEFAULT NULL,
  `content_version` int(11) NOT NULL DEFAULT 0,
  `milestone_id` bigint(20) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `is_closed` tinyint(1) DEFAULT NULL,
  `is_pull` tinyint(1) DEFAULT NULL,
  `num_comments` int(11) DEFAULT NULL,
  `ref` varchar(255) DEFAULT NULL,
  `deadline_unix` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `closed_unix` bigint(20) DEFAULT NULL,
  `is_locked` tinyint(1) NOT NULL DEFAULT 0,
  `time_estimate` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_issue_repo_index` (`repo_id`,`index`),
  KEY `IDX_issue_milestone_id` (`milestone_id`),
  KEY `IDX_issue_is_closed` (`is_closed`),
  KEY `IDX_issue_deadline_unix` (`deadline_unix`),
  KEY `IDX_issue_created_unix` (`created_unix`),
  KEY `IDX_issue_updated_unix` (`updated_unix`),
  KEY `IDX_issue_repo_id` (`repo_id`),
  KEY `IDX_issue_poster_id` (`poster_id`),
  KEY `IDX_issue_original_author_id` (`original_author_id`),
  KEY `IDX_issue_is_pull` (`is_pull`),
  KEY `IDX_issue_closed_unix` (`closed_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue_assignees definition

CREATE TABLE `issue_assignees` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `assignee_id` bigint(20) DEFAULT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_issue_assignees_assignee_id` (`assignee_id`),
  KEY `IDX_issue_assignees_issue_id` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue_content_history definition

CREATE TABLE `issue_content_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `poster_id` bigint(20) DEFAULT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  `comment_id` bigint(20) DEFAULT NULL,
  `edited_unix` bigint(20) DEFAULT NULL,
  `content_text` longtext DEFAULT NULL,
  `is_first_created` tinyint(1) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_issue_content_history_issue_id` (`issue_id`),
  KEY `IDX_issue_content_history_comment_id` (`comment_id`),
  KEY `IDX_issue_content_history_edited_unix` (`edited_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue_dependency definition

CREATE TABLE `issue_dependency` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `issue_id` bigint(20) NOT NULL,
  `dependency_id` bigint(20) NOT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_issue_dependency_issue_dependency` (`issue_id`,`dependency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue_index definition

CREATE TABLE `issue_index` (
  `group_id` bigint(20) NOT NULL,
  `max_index` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`group_id`),
  KEY `IDX_issue_index_max_index` (`max_index`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue_label definition

CREATE TABLE `issue_label` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(20) DEFAULT NULL,
  `label_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_issue_label_s` (`issue_id`,`label_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue_pin definition

CREATE TABLE `issue_pin` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) NOT NULL,
  `issue_id` bigint(20) NOT NULL,
  `is_pull` tinyint(1) NOT NULL,
  `pin_order` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_issue_pin_s` (`repo_id`,`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue_user definition

CREATE TABLE `issue_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT NULL,
  `is_mentioned` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_issue_user_uid_to_issue` (`uid`,`issue_id`),
  KEY `IDX_issue_user_uid` (`uid`),
  KEY `IDX_issue_user_issue_id` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.issue_watch definition

CREATE TABLE `issue_watch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `issue_id` bigint(20) NOT NULL,
  `is_watching` tinyint(1) NOT NULL,
  `created_unix` bigint(20) NOT NULL,
  `updated_unix` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_issue_watch_watch` (`user_id`,`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.label definition

CREATE TABLE `label` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `org_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `exclusive` tinyint(1) DEFAULT NULL,
  `exclusive_order` int(11) DEFAULT 0,
  `description` varchar(255) DEFAULT NULL,
  `color` varchar(7) DEFAULT NULL,
  `num_issues` int(11) DEFAULT NULL,
  `num_closed_issues` int(11) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `archived_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_label_org_id` (`org_id`),
  KEY `IDX_label_created_unix` (`created_unix`),
  KEY `IDX_label_updated_unix` (`updated_unix`),
  KEY `IDX_label_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.language_stat definition

CREATE TABLE `language_stat` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) NOT NULL,
  `commit_id` varchar(255) DEFAULT NULL,
  `is_primary` tinyint(1) DEFAULT NULL,
  `language` varchar(50) NOT NULL,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_language_stat_s` (`repo_id`,`language`),
  KEY `IDX_language_stat_repo_id` (`repo_id`),
  KEY `IDX_language_stat_language` (`language`),
  KEY `IDX_language_stat_created_unix` (`created_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.lfs_lock definition

CREATE TABLE `lfs_lock` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) NOT NULL,
  `owner_id` bigint(20) NOT NULL,
  `path` text DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_lfs_lock_repo_id` (`repo_id`),
  KEY `IDX_lfs_lock_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.lfs_meta_object definition

CREATE TABLE `lfs_meta_object` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `oid` varchar(255) NOT NULL,
  `size` bigint(20) NOT NULL,
  `repository_id` bigint(20) NOT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_lfs_meta_object_s` (`oid`,`repository_id`),
  KEY `IDX_lfs_meta_object_updated_unix` (`updated_unix`),
  KEY `IDX_lfs_meta_object_oid` (`oid`),
  KEY `IDX_lfs_meta_object_repository_id` (`repository_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.login_source definition

CREATE TABLE `login_source` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 0,
  `is_sync_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `two_factor_policy` varchar(255) NOT NULL DEFAULT '',
  `cfg` text DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_login_source_name` (`name`),
  KEY `IDX_login_source_is_sync_enabled` (`is_sync_enabled`),
  KEY `IDX_login_source_created_unix` (`created_unix`),
  KEY `IDX_login_source_updated_unix` (`updated_unix`),
  KEY `IDX_login_source_is_active` (`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.milestone definition

CREATE TABLE `milestone` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `is_closed` tinyint(1) DEFAULT NULL,
  `num_issues` int(11) DEFAULT NULL,
  `num_closed_issues` int(11) DEFAULT NULL,
  `completeness` int(11) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `deadline_unix` bigint(20) DEFAULT NULL,
  `closed_date_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_milestone_created_unix` (`created_unix`),
  KEY `IDX_milestone_updated_unix` (`updated_unix`),
  KEY `IDX_milestone_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.mirror definition

CREATE TABLE `mirror` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `interval` bigint(20) DEFAULT NULL,
  `enable_prune` tinyint(1) NOT NULL DEFAULT 1,
  `updated_unix` bigint(20) DEFAULT NULL,
  `next_update_unix` bigint(20) DEFAULT NULL,
  `lfs_enabled` tinyint(1) NOT NULL DEFAULT 0,
  `lfs_endpoint` text DEFAULT NULL,
  `remote_address` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_mirror_updated_unix` (`updated_unix`),
  KEY `IDX_mirror_next_update_unix` (`next_update_unix`),
  KEY `IDX_mirror_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.notice definition

CREATE TABLE `notice` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_notice_created_unix` (`created_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.notification definition

CREATE TABLE `notification` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `repo_id` bigint(20) NOT NULL,
  `status` smallint(6) NOT NULL,
  `source` smallint(6) NOT NULL,
  `issue_id` bigint(20) NOT NULL,
  `commit_id` varchar(255) DEFAULT NULL,
  `comment_id` bigint(20) DEFAULT NULL,
  `updated_by` bigint(20) NOT NULL,
  `created_unix` bigint(20) NOT NULL,
  `updated_unix` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_notification_idx_notification_repo_id` (`repo_id`),
  KEY `IDX_notification_idx_notification_status` (`status`),
  KEY `IDX_notification_idx_notification_source` (`source`),
  KEY `IDX_notification_idx_notification_issue_id` (`issue_id`),
  KEY `IDX_notification_idx_notification_commit_id` (`commit_id`),
  KEY `IDX_notification_idx_notification_updated_by` (`updated_by`),
  KEY `IDX_notification_u_s_uu` (`user_id`,`status`,`updated_unix`),
  KEY `IDX_notification_idx_notification_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.oauth2_application definition

CREATE TABLE `oauth2_application` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `client_id` varchar(255) DEFAULT NULL,
  `client_secret` varchar(255) DEFAULT NULL,
  `confidential_client` tinyint(1) NOT NULL DEFAULT 1,
  `skip_secondary_authorization` tinyint(1) NOT NULL DEFAULT 0,
  `redirect_uris` text DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_oauth2_application_client_id` (`client_id`),
  KEY `IDX_oauth2_application_updated_unix` (`updated_unix`),
  KEY `IDX_oauth2_application_uid` (`uid`),
  KEY `IDX_oauth2_application_created_unix` (`created_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.oauth2_authorization_code definition

CREATE TABLE `oauth2_authorization_code` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `grant_id` bigint(20) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `code_challenge` varchar(255) DEFAULT NULL,
  `code_challenge_method` varchar(255) DEFAULT NULL,
  `redirect_uri` varchar(255) DEFAULT NULL,
  `valid_until` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_oauth2_authorization_code_code` (`code`),
  KEY `IDX_oauth2_authorization_code_valid_until` (`valid_until`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.oauth2_grant definition

CREATE TABLE `oauth2_grant` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `application_id` bigint(20) DEFAULT NULL,
  `counter` bigint(20) NOT NULL DEFAULT 1,
  `scope` text DEFAULT NULL,
  `nonce` text DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_oauth2_grant_user_application` (`user_id`,`application_id`),
  KEY `IDX_oauth2_grant_user_id` (`user_id`),
  KEY `IDX_oauth2_grant_application_id` (`application_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.org_user definition

CREATE TABLE `org_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL,
  `org_id` bigint(20) DEFAULT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_org_user_s` (`uid`,`org_id`),
  KEY `IDX_org_user_org_id` (`org_id`),
  KEY `IDX_org_user_is_public` (`is_public`),
  KEY `IDX_org_user_uid` (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.package definition

CREATE TABLE `package` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) NOT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lower_name` varchar(255) NOT NULL,
  `semver_compatible` tinyint(1) NOT NULL DEFAULT 0,
  `is_internal` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_package_s` (`owner_id`,`type`,`lower_name`),
  KEY `IDX_package_owner_id` (`owner_id`),
  KEY `IDX_package_repo_id` (`repo_id`),
  KEY `IDX_package_type` (`type`),
  KEY `IDX_package_lower_name` (`lower_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.package_blob definition

CREATE TABLE `package_blob` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `hash_md5` char(32) NOT NULL,
  `hash_sha1` char(40) NOT NULL,
  `hash_sha256` char(64) NOT NULL,
  `hash_sha512` char(128) NOT NULL,
  `created_unix` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_package_blob_sha1` (`hash_sha1`),
  UNIQUE KEY `UQE_package_blob_sha256` (`hash_sha256`),
  UNIQUE KEY `UQE_package_blob_sha512` (`hash_sha512`),
  UNIQUE KEY `UQE_package_blob_md5` (`hash_md5`),
  KEY `IDX_package_blob_hash_md5` (`hash_md5`),
  KEY `IDX_package_blob_created_unix` (`created_unix`),
  KEY `IDX_package_blob_hash_sha1` (`hash_sha1`),
  KEY `IDX_package_blob_hash_sha256` (`hash_sha256`),
  KEY `IDX_package_blob_hash_sha512` (`hash_sha512`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.package_blob_upload definition

CREATE TABLE `package_blob_upload` (
  `id` varchar(255) NOT NULL,
  `bytes_received` bigint(20) NOT NULL DEFAULT 0,
  `hash_state_bytes` blob DEFAULT NULL,
  `created_unix` bigint(20) NOT NULL,
  `updated_unix` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_package_blob_upload_updated_unix` (`updated_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.package_cleanup_rule definition

CREATE TABLE `package_cleanup_rule` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `enabled` tinyint(1) NOT NULL DEFAULT 0,
  `owner_id` bigint(20) NOT NULL DEFAULT 0,
  `type` varchar(255) NOT NULL,
  `keep_count` int(11) NOT NULL DEFAULT 0,
  `keep_pattern` varchar(255) NOT NULL DEFAULT '',
  `remove_days` int(11) NOT NULL DEFAULT 0,
  `remove_pattern` varchar(255) NOT NULL DEFAULT '',
  `match_full_name` tinyint(1) NOT NULL DEFAULT 0,
  `created_unix` bigint(20) NOT NULL DEFAULT 0,
  `updated_unix` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_package_cleanup_rule_s` (`owner_id`,`type`),
  KEY `IDX_package_cleanup_rule_enabled` (`enabled`),
  KEY `IDX_package_cleanup_rule_owner_id` (`owner_id`),
  KEY `IDX_package_cleanup_rule_type` (`type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.package_file definition

CREATE TABLE `package_file` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version_id` bigint(20) NOT NULL,
  `blob_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `lower_name` varchar(255) NOT NULL,
  `composite_key` varchar(255) DEFAULT NULL,
  `is_lead` tinyint(1) NOT NULL DEFAULT 0,
  `created_unix` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_package_file_s` (`version_id`,`lower_name`,`composite_key`),
  KEY `IDX_package_file_composite_key` (`composite_key`),
  KEY `IDX_package_file_created_unix` (`created_unix`),
  KEY `IDX_package_file_version_id` (`version_id`),
  KEY `IDX_package_file_blob_id` (`blob_id`),
  KEY `IDX_package_file_lower_name` (`lower_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.package_property definition

CREATE TABLE `package_property` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `ref_type` bigint(20) NOT NULL,
  `ref_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `value` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_package_property_ref_type` (`ref_type`),
  KEY `IDX_package_property_ref_id` (`ref_id`),
  KEY `IDX_package_property_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.package_version definition

CREATE TABLE `package_version` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `package_id` bigint(20) NOT NULL,
  `creator_id` bigint(20) NOT NULL DEFAULT 0,
  `version` varchar(255) NOT NULL,
  `lower_version` varchar(255) NOT NULL,
  `created_unix` bigint(20) NOT NULL,
  `is_internal` tinyint(1) NOT NULL DEFAULT 0,
  `metadata_json` longtext DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_package_version_s` (`package_id`,`lower_version`),
  KEY `IDX_package_version_package_id` (`package_id`),
  KEY `IDX_package_version_lower_version` (`lower_version`),
  KEY `IDX_package_version_created_unix` (`created_unix`),
  KEY `IDX_package_version_is_internal` (`is_internal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.project definition

CREATE TABLE `project` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `creator_id` bigint(20) NOT NULL,
  `is_closed` tinyint(1) DEFAULT NULL,
  `board_type` int(10) unsigned DEFAULT NULL,
  `card_type` int(10) unsigned DEFAULT NULL,
  `type` int(10) unsigned DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `closed_date_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_project_title` (`title`),
  KEY `IDX_project_owner_id` (`owner_id`),
  KEY `IDX_project_repo_id` (`repo_id`),
  KEY `IDX_project_is_closed` (`is_closed`),
  KEY `IDX_project_created_unix` (`created_unix`),
  KEY `IDX_project_updated_unix` (`updated_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.project_board definition

CREATE TABLE `project_board` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `default` tinyint(1) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `color` varchar(7) DEFAULT NULL,
  `project_id` bigint(20) NOT NULL,
  `creator_id` bigint(20) NOT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_project_board_project_id` (`project_id`),
  KEY `IDX_project_board_created_unix` (`created_unix`),
  KEY `IDX_project_board_updated_unix` (`updated_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.project_issue definition

CREATE TABLE `project_issue` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(20) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `project_board_id` bigint(20) DEFAULT NULL,
  `sorting` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_project_issue_issue_id` (`issue_id`),
  KEY `IDX_project_issue_project_id` (`project_id`),
  KEY `IDX_project_issue_project_board_id` (`project_board_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.protected_branch definition

CREATE TABLE `protected_branch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `branch_name` varchar(255) DEFAULT NULL,
  `priority` bigint(20) NOT NULL DEFAULT 0,
  `can_push` tinyint(1) NOT NULL DEFAULT 0,
  `enable_whitelist` tinyint(1) DEFAULT NULL,
  `whitelist_user_i_ds` text DEFAULT NULL,
  `whitelist_team_i_ds` text DEFAULT NULL,
  `enable_merge_whitelist` tinyint(1) NOT NULL DEFAULT 0,
  `whitelist_deploy_keys` tinyint(1) NOT NULL DEFAULT 0,
  `merge_whitelist_user_i_ds` text DEFAULT NULL,
  `merge_whitelist_team_i_ds` text DEFAULT NULL,
  `can_force_push` tinyint(1) NOT NULL DEFAULT 0,
  `enable_force_push_allowlist` tinyint(1) NOT NULL DEFAULT 0,
  `force_push_allowlist_user_i_ds` text DEFAULT NULL,
  `force_push_allowlist_team_i_ds` text DEFAULT NULL,
  `force_push_allowlist_deploy_keys` tinyint(1) NOT NULL DEFAULT 0,
  `enable_status_check` tinyint(1) NOT NULL DEFAULT 0,
  `status_check_contexts` text DEFAULT NULL,
  `enable_approvals_whitelist` tinyint(1) NOT NULL DEFAULT 0,
  `approvals_whitelist_user_i_ds` text DEFAULT NULL,
  `approvals_whitelist_team_i_ds` text DEFAULT NULL,
  `required_approvals` bigint(20) NOT NULL DEFAULT 0,
  `block_on_rejected_reviews` tinyint(1) NOT NULL DEFAULT 0,
  `block_on_official_review_requests` tinyint(1) NOT NULL DEFAULT 0,
  `block_on_outdated_branch` tinyint(1) NOT NULL DEFAULT 0,
  `dismiss_stale_approvals` tinyint(1) NOT NULL DEFAULT 0,
  `ignore_stale_approvals` tinyint(1) NOT NULL DEFAULT 0,
  `require_signed_commits` tinyint(1) NOT NULL DEFAULT 0,
  `protected_file_patterns` text DEFAULT NULL,
  `unprotected_file_patterns` text DEFAULT NULL,
  `block_admin_merge_override` tinyint(1) NOT NULL DEFAULT 0,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_protected_branch_s` (`repo_id`,`branch_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.protected_tag definition

CREATE TABLE `protected_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `name_pattern` varchar(255) DEFAULT NULL,
  `allowlist_user_i_ds` text DEFAULT NULL,
  `allowlist_team_i_ds` text DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.public_key definition

CREATE TABLE `public_key` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `fingerprint` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `mode` int(11) NOT NULL DEFAULT 2,
  `type` int(11) NOT NULL DEFAULT 1,
  `login_source_id` bigint(20) NOT NULL DEFAULT 0,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_public_key_fingerprint` (`fingerprint`),
  KEY `IDX_public_key_owner_id` (`owner_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.pull_auto_merge definition

CREATE TABLE `pull_auto_merge` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `pull_id` bigint(20) DEFAULT NULL,
  `doer_id` bigint(20) NOT NULL,
  `merge_style` varchar(30) DEFAULT NULL,
  `message` longtext DEFAULT NULL,
  `delete_branch_after_merge` tinyint(1) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_pull_auto_merge_pull_id` (`pull_id`),
  KEY `IDX_pull_auto_merge_doer_id` (`doer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.pull_request definition

CREATE TABLE `pull_request` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `conflicted_files` text DEFAULT NULL,
  `commits_ahead` int(11) DEFAULT NULL,
  `commits_behind` int(11) DEFAULT NULL,
  `changed_protected_files` text DEFAULT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  `index` bigint(20) DEFAULT NULL,
  `head_repo_id` bigint(20) DEFAULT NULL,
  `base_repo_id` bigint(20) DEFAULT NULL,
  `head_branch` varchar(255) DEFAULT NULL,
  `base_branch` varchar(255) DEFAULT NULL,
  `merge_base` varchar(64) DEFAULT NULL,
  `allow_maintainer_edit` tinyint(1) NOT NULL DEFAULT 0,
  `has_merged` tinyint(1) DEFAULT NULL,
  `merged_commit_id` varchar(64) DEFAULT NULL,
  `merger_id` bigint(20) DEFAULT NULL,
  `merged_unix` bigint(20) DEFAULT NULL,
  `flow` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_pull_request_has_merged` (`has_merged`),
  KEY `IDX_pull_request_merger_id` (`merger_id`),
  KEY `IDX_pull_request_merged_unix` (`merged_unix`),
  KEY `IDX_pull_request_issue_id` (`issue_id`),
  KEY `IDX_pull_request_head_repo_id` (`head_repo_id`),
  KEY `IDX_pull_request_base_repo_id` (`base_repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.push_mirror definition

CREATE TABLE `push_mirror` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `remote_name` varchar(255) DEFAULT NULL,
  `remote_address` varchar(2048) DEFAULT NULL,
  `sync_on_commit` tinyint(1) NOT NULL DEFAULT 1,
  `interval` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `last_update` bigint(20) DEFAULT NULL,
  `last_error` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_push_mirror_repo_id` (`repo_id`),
  KEY `IDX_push_mirror_last_update` (`last_update`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.reaction definition

CREATE TABLE `reaction` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  `issue_id` bigint(20) NOT NULL,
  `comment_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) NOT NULL,
  `original_author_id` bigint(20) NOT NULL DEFAULT 0,
  `original_author` varchar(255) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_reaction_s` (`type`,`issue_id`,`comment_id`,`user_id`,`original_author_id`,`original_author`),
  KEY `IDX_reaction_original_author` (`original_author`),
  KEY `IDX_reaction_created_unix` (`created_unix`),
  KEY `IDX_reaction_type` (`type`),
  KEY `IDX_reaction_issue_id` (`issue_id`),
  KEY `IDX_reaction_comment_id` (`comment_id`),
  KEY `IDX_reaction_user_id` (`user_id`),
  KEY `IDX_reaction_original_author_id` (`original_author_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.`release` definition

CREATE TABLE `release` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `publisher_id` bigint(20) DEFAULT NULL,
  `tag_name` varchar(255) DEFAULT NULL,
  `original_author` varchar(255) DEFAULT NULL,
  `original_author_id` bigint(20) DEFAULT NULL,
  `lower_tag_name` varchar(255) DEFAULT NULL,
  `target` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `sha1` varchar(64) DEFAULT NULL,
  `num_commits` bigint(20) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `is_draft` tinyint(1) NOT NULL DEFAULT 0,
  `is_prerelease` tinyint(1) NOT NULL DEFAULT 0,
  `is_tag` tinyint(1) NOT NULL DEFAULT 0,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_release_n` (`repo_id`,`tag_name`),
  KEY `IDX_release_created_unix` (`created_unix`),
  KEY `IDX_release_repo_id` (`repo_id`),
  KEY `IDX_release_publisher_id` (`publisher_id`),
  KEY `IDX_release_tag_name` (`tag_name`),
  KEY `IDX_release_original_author_id` (`original_author_id`),
  KEY `IDX_release_sha1` (`sha1`)
) ENGINE=InnoDB AUTO_INCREMENT=205 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.renamed_branch definition

CREATE TABLE `renamed_branch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) NOT NULL,
  `from` varchar(255) DEFAULT NULL,
  `to` varchar(255) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_renamed_branch_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.repo_archiver definition

CREATE TABLE `repo_archiver` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `commit_id` varchar(64) DEFAULT NULL,
  `created_unix` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_repo_archiver_s` (`repo_id`,`type`,`commit_id`),
  KEY `IDX_repo_archiver_repo_id` (`repo_id`),
  KEY `IDX_repo_archiver_created_unix` (`created_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.repo_indexer_status definition

CREATE TABLE `repo_indexer_status` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `commit_sha` varchar(64) DEFAULT NULL,
  `indexer_type` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_repo_indexer_status_s` (`repo_id`,`indexer_type`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.repo_license definition

CREATE TABLE `repo_license` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) NOT NULL,
  `commit_id` varchar(255) DEFAULT NULL,
  `license` varchar(255) NOT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_repo_license_s` (`repo_id`,`license`),
  KEY `IDX_repo_license_created_unix` (`created_unix`),
  KEY `IDX_repo_license_updated_unix` (`updated_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.repo_redirect definition

CREATE TABLE `repo_redirect` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) DEFAULT NULL,
  `lower_name` varchar(255) NOT NULL,
  `redirect_repo_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_repo_redirect_s` (`owner_id`,`lower_name`),
  KEY `IDX_repo_redirect_lower_name` (`lower_name`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.repo_topic definition

CREATE TABLE `repo_topic` (
  `repo_id` bigint(20) NOT NULL,
  `topic_id` bigint(20) NOT NULL,
  PRIMARY KEY (`repo_id`,`topic_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.repo_transfer definition

CREATE TABLE `repo_transfer` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `doer_id` bigint(20) DEFAULT NULL,
  `recipient_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `team_i_ds` text DEFAULT NULL,
  `created_unix` bigint(20) NOT NULL,
  `updated_unix` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_repo_transfer_created_unix` (`created_unix`),
  KEY `IDX_repo_transfer_updated_unix` (`updated_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.repo_unit definition

CREATE TABLE `repo_unit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `config` text DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `anonymous_access_mode` int(11) NOT NULL DEFAULT 0,
  `everyone_access_mode` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_repo_unit_s` (`repo_id`,`type`),
  KEY `IDX_repo_unit_created_unix` (`created_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=160 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.repository definition

CREATE TABLE `repository` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) DEFAULT NULL,
  `owner_name` varchar(255) DEFAULT NULL,
  `lower_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `website` varchar(2048) DEFAULT NULL,
  `original_service_type` int(11) DEFAULT NULL,
  `original_url` varchar(2048) DEFAULT NULL,
  `default_branch` varchar(255) DEFAULT NULL,
  `default_wiki_branch` varchar(255) DEFAULT NULL,
  `num_watches` int(11) DEFAULT NULL,
  `num_stars` int(11) DEFAULT NULL,
  `num_forks` int(11) DEFAULT NULL,
  `num_issues` int(11) DEFAULT NULL,
  `num_closed_issues` int(11) DEFAULT NULL,
  `num_pulls` int(11) DEFAULT NULL,
  `num_closed_pulls` int(11) DEFAULT NULL,
  `num_milestones` int(11) NOT NULL DEFAULT 0,
  `num_closed_milestones` int(11) NOT NULL DEFAULT 0,
  `num_projects` int(11) NOT NULL DEFAULT 0,
  `num_closed_projects` int(11) NOT NULL DEFAULT 0,
  `num_action_runs` int(11) NOT NULL DEFAULT 0,
  `num_closed_action_runs` int(11) NOT NULL DEFAULT 0,
  `is_private` tinyint(1) DEFAULT NULL,
  `is_empty` tinyint(1) DEFAULT NULL,
  `is_archived` tinyint(1) DEFAULT NULL,
  `is_mirror` tinyint(1) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  `is_fork` tinyint(1) NOT NULL DEFAULT 0,
  `fork_id` bigint(20) DEFAULT NULL,
  `is_template` tinyint(1) NOT NULL DEFAULT 0,
  `template_id` bigint(20) DEFAULT NULL,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `git_size` bigint(20) NOT NULL DEFAULT 0,
  `lfs_size` bigint(20) NOT NULL DEFAULT 0,
  `is_fsck_enabled` tinyint(1) NOT NULL DEFAULT 1,
  `close_issues_via_commit_in_any_branch` tinyint(1) NOT NULL DEFAULT 0,
  `topics` text DEFAULT NULL,
  `object_format_name` varchar(6) NOT NULL DEFAULT 'sha1',
  `trust_model` int(11) DEFAULT NULL,
  `avatar` varchar(64) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `archived_unix` bigint(20) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_repository_s` (`owner_id`,`lower_name`),
  KEY `IDX_repository_is_private` (`is_private`),
  KEY `IDX_repository_is_fork` (`is_fork`),
  KEY `IDX_repository_template_id` (`template_id`),
  KEY `IDX_repository_owner_id` (`owner_id`),
  KEY `IDX_repository_name` (`name`),
  KEY `IDX_repository_is_template` (`is_template`),
  KEY `IDX_repository_created_unix` (`created_unix`),
  KEY `IDX_repository_lower_name` (`lower_name`),
  KEY `IDX_repository_original_service_type` (`original_service_type`),
  KEY `IDX_repository_is_empty` (`is_empty`),
  KEY `IDX_repository_is_archived` (`is_archived`),
  KEY `IDX_repository_is_mirror` (`is_mirror`),
  KEY `IDX_repository_fork_id` (`fork_id`),
  KEY `IDX_repository_updated_unix` (`updated_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.review definition

CREATE TABLE `review` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `reviewer_id` bigint(20) DEFAULT NULL,
  `reviewer_team_id` bigint(20) NOT NULL DEFAULT 0,
  `original_author` varchar(255) DEFAULT NULL,
  `original_author_id` bigint(20) DEFAULT NULL,
  `issue_id` bigint(20) DEFAULT NULL,
  `content` text DEFAULT NULL,
  `official` tinyint(1) NOT NULL DEFAULT 0,
  `commit_id` varchar(64) DEFAULT NULL,
  `stale` tinyint(1) NOT NULL DEFAULT 0,
  `dismissed` tinyint(1) NOT NULL DEFAULT 0,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_review_reviewer_id` (`reviewer_id`),
  KEY `IDX_review_issue_id` (`issue_id`),
  KEY `IDX_review_created_unix` (`created_unix`),
  KEY `IDX_review_updated_unix` (`updated_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.review_state definition

CREATE TABLE `review_state` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `pull_id` bigint(20) NOT NULL DEFAULT 0,
  `commit_sha` varchar(64) NOT NULL,
  `updated_files` longtext NOT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_review_state_pull_commit_user` (`user_id`,`pull_id`,`commit_sha`),
  KEY `IDX_review_state_pull_id` (`pull_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.secret definition

CREATE TABLE `secret` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `owner_id` bigint(20) NOT NULL,
  `repo_id` bigint(20) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `data` longtext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_unix` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_secret_owner_repo_name` (`owner_id`,`repo_id`,`name`),
  KEY `IDX_secret_owner_id` (`owner_id`),
  KEY `IDX_secret_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.`session` definition

CREATE TABLE `session` (
  `key` char(16) NOT NULL,
  `data` blob DEFAULT NULL,
  `expiry` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.star definition

CREATE TABLE `star` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_star_s` (`uid`,`repo_id`),
  KEY `IDX_star_created_unix` (`created_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.stopwatch definition

CREATE TABLE `stopwatch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_stopwatch_issue_id` (`issue_id`),
  KEY `IDX_stopwatch_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.system_setting definition

CREATE TABLE `system_setting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(255) DEFAULT NULL,
  `setting_value` text DEFAULT NULL,
  `version` int(11) DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  `updated` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_system_setting_setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.task definition

CREATE TABLE `task` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `doer_id` bigint(20) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `start_time` bigint(20) DEFAULT NULL,
  `end_time` bigint(20) DEFAULT NULL,
  `payload_content` text DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_task_status` (`status`),
  KEY `IDX_task_doer_id` (`doer_id`),
  KEY `IDX_task_owner_id` (`owner_id`),
  KEY `IDX_task_repo_id` (`repo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.team definition

CREATE TABLE `team` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) DEFAULT NULL,
  `lower_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `authorize` int(11) DEFAULT NULL,
  `num_repos` int(11) DEFAULT NULL,
  `num_members` int(11) DEFAULT NULL,
  `includes_all_repositories` tinyint(1) NOT NULL DEFAULT 0,
  `can_create_org_repo` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_team_org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.team_invite definition

CREATE TABLE `team_invite` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `token` varchar(255) NOT NULL DEFAULT '',
  `inviter_id` bigint(20) NOT NULL DEFAULT 0,
  `org_id` bigint(20) NOT NULL DEFAULT 0,
  `team_id` bigint(20) NOT NULL DEFAULT 0,
  `email` varchar(255) NOT NULL DEFAULT '',
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_team_invite_team_mail` (`team_id`,`email`),
  KEY `IDX_team_invite_created_unix` (`created_unix`),
  KEY `IDX_team_invite_updated_unix` (`updated_unix`),
  KEY `IDX_team_invite_token` (`token`),
  KEY `IDX_team_invite_org_id` (`org_id`),
  KEY `IDX_team_invite_team_id` (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.team_repo definition

CREATE TABLE `team_repo` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_team_repo_s` (`team_id`,`repo_id`),
  KEY `IDX_team_repo_org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.team_unit definition

CREATE TABLE `team_unit` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `access_mode` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_team_unit_s` (`team_id`,`type`),
  KEY `IDX_team_unit_org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.team_user definition

CREATE TABLE `team_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `org_id` bigint(20) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  `uid` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_team_user_s` (`team_id`,`uid`),
  KEY `IDX_team_user_org_id` (`org_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.topic definition

CREATE TABLE `topic` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `repo_count` int(11) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_topic_name` (`name`),
  KEY `IDX_topic_created_unix` (`created_unix`),
  KEY `IDX_topic_updated_unix` (`updated_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.tracked_time definition

CREATE TABLE `tracked_time` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `issue_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `time` bigint(20) NOT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `IDX_tracked_time_user_id` (`user_id`),
  KEY `IDX_tracked_time_issue_id` (`issue_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.two_factor definition

CREATE TABLE `two_factor` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) DEFAULT NULL,
  `secret` varchar(255) DEFAULT NULL,
  `scratch_salt` varchar(255) DEFAULT NULL,
  `scratch_hash` varchar(255) DEFAULT NULL,
  `last_used_passcode` varchar(10) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_two_factor_uid` (`uid`),
  KEY `IDX_two_factor_created_unix` (`created_unix`),
  KEY `IDX_two_factor_updated_unix` (`updated_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.upload definition

CREATE TABLE `upload` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uuid` varchar(40) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_upload_uuid` (`uuid`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.`user` definition

CREATE TABLE `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lower_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `keep_email_private` tinyint(1) DEFAULT NULL,
  `email_notifications_preference` varchar(20) NOT NULL DEFAULT 'enabled',
  `passwd` varchar(255) NOT NULL,
  `passwd_hash_algo` varchar(255) NOT NULL DEFAULT 'argon2',
  `must_change_password` tinyint(1) NOT NULL DEFAULT 0,
  `login_type` int(11) DEFAULT NULL,
  `login_source` bigint(20) NOT NULL DEFAULT 0,
  `login_name` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `rands` varchar(32) DEFAULT NULL,
  `salt` varchar(32) DEFAULT NULL,
  `language` varchar(5) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  `last_login_unix` bigint(20) DEFAULT NULL,
  `last_repo_visibility` tinyint(1) DEFAULT NULL,
  `max_repo_creation` int(11) NOT NULL DEFAULT -1,
  `is_active` tinyint(1) DEFAULT NULL,
  `is_admin` tinyint(1) DEFAULT NULL,
  `is_restricted` tinyint(1) NOT NULL DEFAULT 0,
  `allow_git_hook` tinyint(1) DEFAULT NULL,
  `allow_import_local` tinyint(1) DEFAULT NULL,
  `allow_create_organization` tinyint(1) DEFAULT 1,
  `prohibit_login` tinyint(1) NOT NULL DEFAULT 0,
  `avatar` varchar(2048) NOT NULL,
  `avatar_email` varchar(255) NOT NULL,
  `use_custom_avatar` tinyint(1) DEFAULT NULL,
  `num_followers` int(11) DEFAULT NULL,
  `num_following` int(11) NOT NULL DEFAULT 0,
  `num_stars` int(11) DEFAULT NULL,
  `num_repos` int(11) DEFAULT NULL,
  `num_teams` int(11) DEFAULT NULL,
  `num_members` int(11) DEFAULT NULL,
  `visibility` int(11) NOT NULL DEFAULT 0,
  `repo_admin_change_team_access` tinyint(1) NOT NULL DEFAULT 0,
  `diff_view_style` varchar(255) NOT NULL DEFAULT '',
  `theme` varchar(255) NOT NULL DEFAULT '',
  `keep_activity_private` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_user_lower_name` (`lower_name`),
  UNIQUE KEY `UQE_user_name` (`name`),
  KEY `IDX_user_created_unix` (`created_unix`),
  KEY `IDX_user_updated_unix` (`updated_unix`),
  KEY `IDX_user_last_login_unix` (`last_login_unix`),
  KEY `IDX_user_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.user_badge definition

CREATE TABLE `user_badge` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `badge_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_user_badge_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.user_blocking definition

CREATE TABLE `user_blocking` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `blocker_id` bigint(20) DEFAULT NULL,
  `blockee_id` bigint(20) DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_user_blocking_block` (`blocker_id`,`blockee_id`),
  KEY `IDX_user_blocking_created_unix` (`created_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.user_open_id definition

CREATE TABLE `user_open_id` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `uid` bigint(20) NOT NULL,
  `uri` varchar(255) NOT NULL,
  `show` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_user_open_id_uri` (`uri`),
  KEY `IDX_user_open_id_uid` (`uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.user_redirect definition

CREATE TABLE `user_redirect` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lower_name` varchar(255) NOT NULL,
  `redirect_user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_user_redirect_s` (`lower_name`),
  KEY `IDX_user_redirect_lower_name` (`lower_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.user_setting definition

CREATE TABLE `user_setting` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `setting_key` varchar(255) DEFAULT NULL,
  `setting_value` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_user_setting_key_userid` (`user_id`,`setting_key`),
  KEY `IDX_user_setting_user_id` (`user_id`),
  KEY `IDX_user_setting_setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.version definition

CREATE TABLE `version` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `version` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.watch definition

CREATE TABLE `watch` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL,
  `repo_id` bigint(20) DEFAULT NULL,
  `mode` smallint(6) NOT NULL DEFAULT 1,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_watch_watch` (`user_id`,`repo_id`),
  KEY `IDX_watch_created_unix` (`created_unix`),
  KEY `IDX_watch_updated_unix` (`updated_unix`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.webauthn_credential definition

CREATE TABLE `webauthn_credential` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `lower_name` varchar(255) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `credential_id` varbinary(1024) DEFAULT NULL,
  `public_key` blob DEFAULT NULL,
  `attestation_type` varchar(255) DEFAULT NULL,
  `aaguid` blob DEFAULT NULL,
  `sign_count` bigint(20) DEFAULT NULL,
  `clone_warning` tinyint(1) DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UQE_webauthn_credential_s` (`lower_name`,`user_id`),
  KEY `IDX_webauthn_credential_user_id` (`user_id`),
  KEY `IDX_webauthn_credential_credential_id` (`credential_id`),
  KEY `IDX_webauthn_credential_created_unix` (`created_unix`),
  KEY `IDX_webauthn_credential_updated_unix` (`updated_unix`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;


-- dbpoac.webhook definition

CREATE TABLE `webhook` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repo_id` bigint(20) DEFAULT NULL,
  `owner_id` bigint(20) DEFAULT NULL,
  `is_system_webhook` tinyint(1) DEFAULT NULL,
  `url` text DEFAULT NULL,
  `http_method` varchar(255) DEFAULT NULL,
  `content_type` int(11) DEFAULT NULL,
  `secret` text DEFAULT NULL,
  `events` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `type` varchar(16) DEFAULT NULL,
  `meta` text DEFAULT NULL,
  `last_status` int(11) DEFAULT NULL,
  `header_authorization_encrypted` text DEFAULT NULL,
  `created_unix` bigint(20) DEFAULT NULL,
  `updated_unix` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_webhook_is_active` (`is_active`),
  KEY `IDX_webhook_created_unix` (`created_unix`),
  KEY `IDX_webhook_updated_unix` (`updated_unix`),
  KEY `IDX_webhook_repo_id` (`repo_id`),
  KEY `IDX_webhook_owner_id` (`owner_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_as_cs ROW_FORMAT=DYNAMIC;