-- dbpoap.api_applicable_policy definition

CREATE TABLE `api_applicable_policy` (
  `API_ID` varchar(36) NOT NULL COMMENT 'API ID',
  `API_POLICY_ID` varchar(36) NOT NULL COMMENT '적용가능 정책 ID',
  PRIMARY KEY (`API_ID`,`API_POLICY_ID`),
  KEY `API_APPLICABLE_POLICY_FK` (`API_POLICY_ID`) USING BTREE,
  CONSTRAINT `API_APPLICABLE_POLICY_FK` FOREIGN KEY (`API_POLICY_ID`) REFERENCES `api_policy` (`API_POLICY_ID`),
  CONSTRAINT `FK_AAP_AID_AI_AID` FOREIGN KEY (`API_ID`) REFERENCES `api_info` (`API_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 정보';


-- dbpoap.api_applicable_policy_aud definition

CREATE TABLE `api_applicable_policy_aud` (
  `API_ID` varchar(36) NOT NULL COMMENT 'API ID',
  `API_POLICY_ID` varchar(36) NOT NULL COMMENT '적용가능 정책 ID',
  `REV` decimal(20,0) NOT NULL COMMENT '버전',
  `REVTYPE` char(1) NOT NULL COMMENT '버전타입(C:create, U:update, D:delete)',
  PRIMARY KEY (`API_ID`,`API_POLICY_ID`,`REV`,`REVTYPE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 정보';

-- dbpoap.api_filter_group_param definition

CREATE TABLE `api_filter_group_param` (
  `API_FILTER_GROUP_PARAM_ID` varchar(36) NOT NULL COMMENT 'ID',
  `API_ID` varchar(36) NOT NULL COMMENT 'API ID',
  `FILTER_GROUP_ID` varchar(36) NOT NULL COMMENT 'FILTER GROUP ID',
  `KEY` varchar(255) NOT NULL COMMENT '키',
  `TYPE` varchar(10) NOT NULL COMMENT '유형',
  `LABEL` varchar(255) NOT NULL COMMENT '표시 이름',
  `VALUE` varchar(255) DEFAULT NULL COMMENT '값',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`API_FILTER_GROUP_PARAM_ID`),
  KEY `FK_AFGP_AID_AI_AID` (`API_ID`) USING BTREE,
  CONSTRAINT `FK_AFGP_AID_AI_AID` FOREIGN KEY (`API_ID`) REFERENCES `api_info` (`API_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API FILTER GROUP 파라미터 관리';

-- dbpoap.api_filter_group_param_aud definition

CREATE TABLE `api_filter_group_param_aud` (
  `API_FILTER_GROUP_PARAM_ID` varchar(36) NOT NULL COMMENT 'ID',
  `REV` decimal(20,0) NOT NULL COMMENT '버전',
  `REVTYPE` char(1) DEFAULT NULL COMMENT '버전타입(C:create, U:update, D:delete)',
  `API_ID` varchar(36) NOT NULL COMMENT 'API ID',
  `FILTER_GROUP_ID` varchar(36) NOT NULL COMMENT 'FILTER GROUP ID',
  `KEY` varchar(255) NOT NULL COMMENT '키',
  `TYPE` varchar(10) NOT NULL COMMENT '유형',
  `LABEL` varchar(255) NOT NULL COMMENT '표시 이름',
  `VALUE` varchar(255) DEFAULT NULL COMMENT '값',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`API_FILTER_GROUP_PARAM_ID`,`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API FILTER GROUP 파라미터 이력';

-- dbpoap.api_group definition

CREATE TABLE `api_group` (
  `API_GROUP_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `NAME` varchar(255) DEFAULT NULL COMMENT '이름',
  `DESCRIPTION` longtext DEFAULT NULL COMMENT '설명',
  `PUBLIC_YN` char(1) NOT NULL DEFAULT 'Y' COMMENT '공개 여부',
  `STATUS` varchar(255) DEFAULT 'Y' COMMENT '상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`API_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 그룹';

-- dbpoap.api_group_and_api definition

CREATE TABLE `api_group_and_api` (
  `API_GROUP_ID` varchar(36) NOT NULL COMMENT 'API 그룹 ID',
  `API_ID` varchar(36) NOT NULL COMMENT 'API ID',
  KEY `API_GROUP_AND_API_FK` (`API_GROUP_ID`) USING BTREE,
  KEY `API_GROUP_AND_API_FK_1` (`API_ID`) USING BTREE,
  CONSTRAINT `API_GROUP_AND_API_FK` FOREIGN KEY (`API_GROUP_ID`) REFERENCES `api_group` (`API_GROUP_ID`),
  CONSTRAINT `API_GROUP_AND_API_FK_1` FOREIGN KEY (`API_ID`) REFERENCES `api_info` (`API_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 그룹 API 맵핑';

-- dbpoap.api_info definition

CREATE TABLE `api_info` (
  `API_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관 ID',
  `API_CODE` varchar(255) NOT NULL COMMENT 'API CODE',
  `API_NAME` varchar(255) NOT NULL COMMENT '이름',
  `API_URI` varchar(255) NOT NULL COMMENT 'API URI',
  `POD_ID` varchar(36) NOT NULL COMMENT 'POD ID',
  `METHOD` varchar(10) DEFAULT NULL COMMENT '메소드 구분(01:GET, 02:POST, 03:PARM, 04:PUT, 05:DELETE)',
  `SCOPE` varchar(50) DEFAULT NULL COMMENT 'SCOPE',
  `DATA_TYPE` char(1) NOT NULL COMMENT '전문 구분',
  `BOUND_TYPE` varchar(10) NOT NULL COMMENT 'Bound타입(01:InBound, 02:OutBound)',
  `ROUTING_URL` varchar(255) DEFAULT NULL COMMENT 'API 호출 URL',
  `DESCRIPTION` longtext DEFAULT NULL COMMENT '설명',
  `USE_YN` char(1) DEFAULT NULL COMMENT '사용 여부',
  `TERMS_OF_USE_ID` varchar(36) DEFAULT NULL COMMENT '약관  ID',
  `VERSION` decimal(10,0) DEFAULT NULL COMMENT '버전',
  `BILLING_POLICY_ID` varchar(36) DEFAULT NULL COMMENT '과금 정책  ID',
  `NEXT_BILLING_POLICY_ID` varchar(36) DEFAULT NULL COMMENT '변경 과금정책',
  `STATUS` varchar(255) DEFAULT NULL COMMENT '상태',
  `PUBLIC_YN` char(1) DEFAULT NULL COMMENT '공개 여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `BODY_TYPE` varchar(10) DEFAULT NULL COMMENT '전문 BODY 유형',
  `PROXY` char(1) DEFAULT NULL COMMENT 'Proxy 여부',
  `DETAIL_STATUS` varchar(255) DEFAULT NULL COMMENT '세부상태(승인상태)',
  `DEPLOY_POD_ID` varchar(36) DEFAULT NULL COMMENT '배포대상 POD ID',
  `BASE64_ENCODING_YN` char(1) DEFAULT NULL COMMENT 'base64 변환유형 인코딩(수신)',
  `BASE64_DECODING_YN` char(1) DEFAULT NULL COMMENT 'base64 변환유형 디코딩(송신)',
  `ITF_MTHD_DV_CD` varchar(2) DEFAULT NULL COMMENT '연계방식구분코드',
  `API_TRSC_DV_CD` varchar(4) DEFAULT NULL COMMENT 'API거래구분코드',
  `OAPI_SYS_DV_CD` varchar(100) DEFAULT NULL,
  `TOKEN_YN` char(1) NOT NULL DEFAULT 'N' COMMENT '토큰 사용유무',
  `DESTINATION_CODE` varchar(255) DEFAULT NULL COMMENT '목적지 코드',
  PRIMARY KEY (`API_ID`),
  KEY `API_INFO_FK` (`ORGANIZATION_ID`) USING BTREE,
  KEY `API_INFO_FK_1` (`POD_ID`) USING BTREE,
  KEY `API_INFO_FK_2` (`TERMS_OF_USE_ID`) USING BTREE,
  CONSTRAINT `API_INFO_FK` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`),
  CONSTRAINT `API_INFO_FK_1` FOREIGN KEY (`POD_ID`) REFERENCES `pod_info` (`POD_ID`),
  CONSTRAINT `API_INFO_FK_2` FOREIGN KEY (`TERMS_OF_USE_ID`) REFERENCES `terms_of_use` (`TERMS_OF_USE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 정보';

-- dbpoap.api_info_aud definition

CREATE TABLE `api_info_aud` (
  `API_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `REV` decimal(20,0) NOT NULL COMMENT '버전',
  `REVTYPE` char(1) DEFAULT NULL COMMENT '버전타입(C:create, U:update, D:delete)',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관 ID',
  `API_CODE` varchar(255) NOT NULL COMMENT 'API CODE',
  `API_NAME` varchar(255) NOT NULL COMMENT '이름',
  `API_URI` varchar(255) NOT NULL COMMENT 'API URI',
  `POD_ID` varchar(36) NOT NULL COMMENT 'POD ID',
  `METHOD` varchar(10) DEFAULT NULL COMMENT '메소드 구분(01:GET, 02:POST, 03:PARM, 04:PUT, 05:DELETE)',
  `SCOPE` varchar(50) DEFAULT NULL COMMENT 'SCOPE',
  `DATA_TYPE` char(1) NOT NULL COMMENT '전문 구분',
  `BOUND_TYPE` varchar(10) NOT NULL COMMENT 'Bound타입(01:InBound, 02:OutBound)',
  `ROUTING_URL` varchar(255) DEFAULT NULL COMMENT 'API 호출 URL',
  `DESCRIPTION` longtext DEFAULT NULL COMMENT '설명',
  `USE_YN` char(1) DEFAULT NULL COMMENT '사용 여부',
  `TERMS_OF_USE_ID` varchar(36) DEFAULT NULL COMMENT '약관  ID',
  `VERSION` decimal(10,0) DEFAULT NULL COMMENT '버전',
  `BILLING_POLICY_ID` varchar(36) DEFAULT NULL COMMENT '과금 정책  ID',
  `NEXT_BILLING_POLICY_ID` varchar(36) DEFAULT NULL COMMENT '변경 과금정책',
  `STATUS` varchar(255) DEFAULT NULL COMMENT '상태',
  `PUBLIC_YN` char(1) DEFAULT NULL COMMENT '공개 여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `BODY_TYPE` varchar(10) DEFAULT NULL COMMENT '전문 BODY 유형',
  `PROXY` char(1) DEFAULT NULL COMMENT 'Proxy 여부',
  `DETAIL_STATUS` varchar(255) DEFAULT NULL COMMENT '세부상태(승인상태)',
  `DEPLOY_POD_ID` varchar(36) DEFAULT NULL COMMENT '배포대상 POD ID',
  `BASE64_ENCODING_YN` char(1) DEFAULT NULL COMMENT 'base64 변환유형 인코딩(수신)',
  `BASE64_DECODING_YN` char(1) DEFAULT NULL COMMENT 'base64 변환유형 디코딩(송신)',
  `ITF_MTHD_DV_CD` varchar(2) DEFAULT NULL COMMENT '연계방식구분코드',
  `API_TRSC_DV_CD` varchar(4) DEFAULT NULL COMMENT 'API거래구분코드',
  PRIMARY KEY (`API_ID`,`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 정보 이력';

-- dbpoap.api_layout definition

CREATE TABLE `api_layout` (
  `API_LAYOUT_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `API_CODE` varchar(50) DEFAULT NULL COMMENT 'API CODE',
  `LAYOUT_TYPE` varchar(5) DEFAULT NULL COMMENT '레이아웃 타입',
  `SEQ` decimal(5,0) DEFAULT NULL COMMENT '순서',
  `KEY` varchar(255) DEFAULT NULL COMMENT '키',
  `TYPE` varchar(10) DEFAULT NULL COMMENT '데이터 유형',
  `NAME` varchar(255) DEFAULT NULL COMMENT '한글명',
  `LENGTH` decimal(10,0) DEFAULT NULL COMMENT '길이',
  `ARRAY_YN` char(1) DEFAULT NULL COMMENT 'ARRAY구분',
  `ARRAY_CNT` varchar(50) DEFAULT NULL COMMENT '반복 횟수 (0 | 1 | 참조컬럼)',
  `ATTR` varchar(10) DEFAULT NULL COMMENT '속성(P:PK, T:PK+SEQUENCE, S: SEQUENCE, M: 다국어)',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `PARENT_SEQ` varchar(36) DEFAULT NULL COMMENT '부모 순서번호',
  PRIMARY KEY (`API_LAYOUT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API LAYOUT I/O 관리';

-- dbpoap.api_manager definition

CREATE TABLE `api_manager` (
  `API_MANAGER_ID` varchar(36) DEFAULT NULL COMMENT 'API 업무담당자',
  `API_ID` varchar(36) DEFAULT NULL COMMENT 'API ID',
  `USER_ID` varchar(36) DEFAULT NULL COMMENT '사용자ID',
  `LOGIN_ID` varchar(50) DEFAULT NULL COMMENT '행번(로그인ID)',
  `USER_NAME` varchar(50) DEFAULT NULL COMMENT '사용자명',
  `PHONE_NO` varchar(15) DEFAULT NULL COMMENT '휴대폰번호',
  `RECORD_STATE` decimal(22,0) DEFAULT NULL COMMENT '레코드상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 업무담당자';

-- dbpoap.api_package_content definition

CREATE TABLE `api_package_content` (
  `API_PACKAGE_CONTENT_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `API_PACKAGE_ID` varchar(36) NOT NULL COMMENT '패키지 ID',
  `TITLE` varchar(300) NOT NULL COMMENT '제목',
  `TEXT1` varchar(300) DEFAULT NULL COMMENT '테스트1',
  `TEXT2` varchar(300) DEFAULT NULL COMMENT '테스트2',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`API_PACKAGE_CONTENT_ID`),
  KEY `API_PACKAGE_CONTENT_FK` (`API_PACKAGE_ID`) USING BTREE,
  CONSTRAINT `API_PACKAGE_CONTENT_FK` FOREIGN KEY (`API_PACKAGE_ID`) REFERENCES `api_package_info` (`API_PACKAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 패키지 특징 컨텐츠';

-- dbpoap.api_package_info definition

CREATE TABLE `api_package_info` (
  `API_PACKAGE_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `API_PACKAGE_TYPE` varchar(50) DEFAULT NULL COMMENT 'API 패키지 타입',
  `API_PACKAGE_NAME` varchar(36) DEFAULT NULL COMMENT '패키지명',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '설명',
  `POINT1` varchar(1000) DEFAULT NULL COMMENT '특징1',
  `POINT2` varchar(1000) DEFAULT NULL COMMENT '특징2',
  `POINT3` varchar(1000) DEFAULT NULL COMMENT '특징3',
  `MAIN_DISPLAY_YN` char(1) DEFAULT NULL COMMENT '메인 노출 여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일',
  `CONTENTS_TYPE` varchar(2) DEFAULT NULL COMMENT '컨텐츠 타입(P:패키지, A: API, AP: 둘다)',
  `MAIN_DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '메인화면의 설명',
  `MAIN_ICON_CLASS` varchar(20) DEFAULT NULL COMMENT '메인화면의 아이콘',
  PRIMARY KEY (`API_PACKAGE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 패키지 정보';

-- dbpoap.api_package_service definition

CREATE TABLE `api_package_service` (
  `API_PACKAGE_SERVICE_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `API_PACKAGE_ID` varchar(36) NOT NULL COMMENT '패키지 ID',
  `API_ID` varchar(36) NOT NULL COMMENT 'API ID',
  `DISPLAY_YN` char(1) DEFAULT NULL COMMENT '노출 여부',
  `RECORD_STATE` decimal(10,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일',
  `API_GROUP_ID` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`API_PACKAGE_SERVICE_ID`),
  KEY `API_PACKAGE_SERVICE_FK` (`API_PACKAGE_ID`) USING BTREE,
  KEY `API_PACKAGE_SERVICE_FK_1` (`API_ID`) USING BTREE,
  CONSTRAINT `API_PACKAGE_SERVICE_FK` FOREIGN KEY (`API_PACKAGE_ID`) REFERENCES `api_package_info` (`API_PACKAGE_ID`),
  CONSTRAINT `API_PACKAGE_SERVICE_FK_1` FOREIGN KEY (`API_ID`) REFERENCES `api_info` (`API_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 패키지 서비스';

-- dbpoap.api_policy definition

CREATE TABLE `api_policy` (
  `API_POLICY_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `NAME` varchar(50) NOT NULL COMMENT '이름',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '설명',
  `CONTROL_DAY` decimal(1,0) DEFAULT NULL COMMENT '요일 제한 설정',
  `CONTROL_TIME` decimal(1,0) DEFAULT NULL COMMENT '시간 제한 설정',
  `END_DAY_OF_WEEK` varchar(255) DEFAULT NULL COMMENT '종료 요일',
  `END_TIME` varchar(255) DEFAULT NULL COMMENT '종료 시간',
  `DEFAULT_PLAN_YN` char(1) NOT NULL COMMENT '기본 정책 여부',
  `SHARED_DEFAULT_PLAN_YN` char(1) NOT NULL COMMENT '범용 정책 여부',
  `MAX_REQUEST_RATE` decimal(38,0) DEFAULT NULL COMMENT '최대 허용 갯수',
  `QUOTA_ENABLED` decimal(1,0) DEFAULT NULL COMMENT '할당량 설정',
  `QUOTA_TIME_UNIT` varchar(255) DEFAULT NULL COMMENT '할당량 시간 단위',
  `QUOTA_VALUE` decimal(38,0) DEFAULT NULL COMMENT '할당량 값',
  `RATE_LIMIT_YN` char(1) DEFAULT NULL COMMENT '제한 여부',
  `START_DAY_OF_WEEK` varchar(255) DEFAULT NULL COMMENT '시작 요일',
  `START_TIME` varchar(255) DEFAULT NULL COMMENT '시작 시간',
  `STATUS` varchar(255) DEFAULT NULL COMMENT '승인 상태',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관 ID',
  `CONTROL_DAY_AND_TIME` decimal(1,0) DEFAULT NULL COMMENT '요일/시간 제한 활성화 여부',
  `RESTRICT_MONDAY` decimal(1,0) DEFAULT NULL COMMENT '월요일 - 요일 제한 활성화 여부',
  `RESTRICT_MONDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '월요일 - 시간 제한 활성화 여부',
  `RESTRICT_MONDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '월요일 - 요청 허용 시작 시간',
  `RESTRICT_MONDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '월요일 - 요청 허용 종료 시간',
  `RESTRICT_TUESDAY` decimal(1,0) DEFAULT NULL COMMENT '화요일 - 요일 제한 활성화 여부',
  `RESTRICT_TUESDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '화요일 - 시간 제한 활성화 여부',
  `RESTRICT_TUESDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '화요일 - 요청 허용 시작 시간',
  `RESTRICT_TUESDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '화요일 - 요청 허용 종료 시간',
  `RESTRICT_WEDNESDAY` decimal(1,0) DEFAULT NULL COMMENT '수요일 - 요일 제한 활성화 여부',
  `RESTRICT_WEDNESDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '수요일 - 시간 제한 활성화 여부',
  `RESTRICT_WEDNESDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '수요일 - 요청 허용 시작 시간',
  `RESTRICT_WEDNESDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '수요일 - 요청 허용 종료 시간',
  `RESTRICT_THURSDAY` decimal(1,0) DEFAULT NULL COMMENT '목요일 - 요일 제한 활성화 여부',
  `RESTRICT_THURSDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '목요일 - 시간 제한 활성화 여부',
  `RESTRICT_THURSDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '목요일 - 요청 허용 시작 시간',
  `RESTRICT_THURSDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '목요일 - 요청 허용 종료 시간',
  `RESTRICT_FRIDAY` decimal(1,0) DEFAULT NULL COMMENT '금요일 - 요일 제한 활성화 여부',
  `RESTRICT_FRIDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '금요일 - 시간 제한 활성화 여부',
  `RESTRICT_FRIDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '금요일 - 요청 허용 시작 시간',
  `RESTRICT_FRIDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '금요일 - 요청 허용 종료 시간',
  `RESTRICT_SATURDAY` decimal(1,0) DEFAULT NULL COMMENT '토요일 - 요일 제한 활성화 여부',
  `RESTRICT_SATURDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '토요일 - 시간 제한 활성화 여부',
  `RESTRICT_SATURDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '토요일 - 요청 허용 시작 시간',
  `RESTRICT_SATURDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '토요일 - 요청 허용 종료 시간',
  `RESTRICT_SUNDAY` decimal(1,0) DEFAULT NULL COMMENT '일요일 - 요일 제한 활성화 여부',
  `RESTRICT_SUNDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '일요일 - 시간 제한 활성화 여부',
  `RESTRICT_SUNDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '일요일 - 요청 허용 시작 시간',
  `RESTRICT_SUNDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '일요일 - 요청 허용 종료 시간',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(50) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(50) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `POD_ID` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`API_POLICY_ID`),
  KEY `FK_AP_OID_ORG_OID` (`ORGANIZATION_ID`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 사용 정책';



-- dbpoap.api_policy_aud definition

CREATE TABLE `api_policy_aud` (
  `API_POLICY_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `REV` decimal(20,0) NOT NULL COMMENT '버전',
  `REVTYPE` char(1) DEFAULT NULL COMMENT '버전타입(C:create, U:update, D:delete)',
  `NAME` varchar(50) NOT NULL COMMENT '이름',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '설명',
  `CONTROL_DAY` decimal(1,0) DEFAULT NULL COMMENT '요일 제한 설정',
  `CONTROL_TIME` decimal(1,0) DEFAULT NULL COMMENT '시간 제한 설정',
  `END_DAY_OF_WEEK` varchar(255) DEFAULT NULL COMMENT '종료 요일',
  `END_TIME` varchar(255) DEFAULT NULL COMMENT '종료 시간',
  `DEFAULT_PLAN_YN` char(1) NOT NULL COMMENT '기본 정책 여부',
  `SHARED_DEFAULT_PLAN_YN` char(1) NOT NULL COMMENT '범용 정책 여부',
  `MAX_REQUEST_RATE` decimal(38,0) DEFAULT NULL COMMENT '최대 허용 갯수',
  `QUOTA_ENABLED` decimal(1,0) DEFAULT NULL COMMENT '할당량 설정',
  `QUOTA_TIME_UNIT` varchar(255) DEFAULT NULL COMMENT '할당량 시간 단위',
  `QUOTA_VALUE` decimal(38,0) DEFAULT NULL COMMENT '할당량 값',
  `RATE_LIMIT_YN` char(1) DEFAULT NULL COMMENT '제한 여부',
  `START_DAY_OF_WEEK` varchar(255) DEFAULT NULL COMMENT '시작 요일',
  `START_TIME` varchar(255) DEFAULT NULL COMMENT '시작 시간',
  `STATUS` varchar(255) DEFAULT NULL COMMENT '승인 상태',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관 ID',
  `CONTROL_DAY_AND_TIME` decimal(1,0) DEFAULT NULL COMMENT '요일/시간 제한 활성화 여부',
  `RESTRICT_MONDAY` decimal(1,0) DEFAULT NULL COMMENT '월요일 - 요일 제한 활성화 여부',
  `RESTRICT_MONDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '월요일 - 시간 제한 활성화 여부',
  `RESTRICT_MONDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '월요일 - 요청 허용 시작 시간',
  `RESTRICT_MONDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '월요일 - 요청 허용 종료 시간',
  `RESTRICT_TUESDAY` decimal(1,0) DEFAULT NULL COMMENT '화요일 - 요일 제한 활성화 여부',
  `RESTRICT_TUESDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '화요일 - 시간 제한 활성화 여부',
  `RESTRICT_TUESDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '화요일 - 요청 허용 시작 시간',
  `RESTRICT_TUESDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '화요일 - 요청 허용 종료 시간',
  `RESTRICT_WEDNESDAY` decimal(1,0) DEFAULT NULL COMMENT '수요일 - 요일 제한 활성화 여부',
  `RESTRICT_WEDNESDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '수요일 - 시간 제한 활성화 여부',
  `RESTRICT_WEDNESDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '수요일 - 요청 허용 시작 시간',
  `RESTRICT_WEDNESDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '수요일 - 요청 허용 종료 시간',
  `RESTRICT_THURSDAY` decimal(1,0) DEFAULT NULL COMMENT '목요일 - 요일 제한 활성화 여부',
  `RESTRICT_THURSDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '목요일 - 시간 제한 활성화 여부',
  `RESTRICT_THURSDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '목요일 - 요청 허용 시작 시간',
  `RESTRICT_THURSDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '목요일 - 요청 허용 종료 시간',
  `RESTRICT_FRIDAY` decimal(1,0) DEFAULT NULL COMMENT '금요일 - 요일 제한 활성화 여부',
  `RESTRICT_FRIDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '금요일 - 시간 제한 활성화 여부',
  `RESTRICT_FRIDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '금요일 - 요청 허용 시작 시간',
  `RESTRICT_FRIDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '금요일 - 요청 허용 종료 시간',
  `RESTRICT_SATURDAY` decimal(1,0) DEFAULT NULL COMMENT '토요일 - 요일 제한 활성화 여부',
  `RESTRICT_SATURDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '토요일 - 시간 제한 활성화 여부',
  `RESTRICT_SATURDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '토요일 - 요청 허용 시작 시간',
  `RESTRICT_SATURDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '토요일 - 요청 허용 종료 시간',
  `RESTRICT_SUNDAY` decimal(1,0) DEFAULT NULL COMMENT '일요일 - 요일 제한 활성화 여부',
  `RESTRICT_SUNDAY_TIME` decimal(1,0) DEFAULT NULL COMMENT '일요일 - 시간 제한 활성화 여부',
  `RESTRICT_SUNDAY_TIME_START` varchar(255) DEFAULT NULL COMMENT '일요일 - 요청 허용 시작 시간',
  `RESTRICT_SUNDAY_TIME_END` varchar(255) DEFAULT NULL COMMENT '일요일 - 요청 허용 종료 시간',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(50) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(50) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `POD_ID` varchar(36) NOT NULL,
  PRIMARY KEY (`API_POLICY_ID`,`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 사용 정책 이력';

-- dbpoap.api_static_exam definition

CREATE TABLE `api_static_exam` (
  `API_STATIC_EXAM_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `API_ID` varchar(255) NOT NULL COMMENT 'API ID',
  `REQ_JSON_EXAM` varchar(4000) NOT NULL COMMENT '요청 JSON 예제',
  `RES_JSON_EXAM` varchar(4000) NOT NULL COMMENT '응답 JSON 예제',
  `RECORD_STATE` decimal(10,0) DEFAULT NULL COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`API_STATIC_EXAM_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 대응답 예시';

-- dbpoap.api_static_resp definition

CREATE TABLE `api_static_resp` (
  `API_STATIC_RESP_ID` varchar(50) NOT NULL COMMENT 'ID',
  `API_ID` varchar(255) NOT NULL COMMENT 'API ID',
  `API_URL` varchar(255) NOT NULL COMMENT 'API URL',
  `SEARCH_COND` longtext DEFAULT NULL COMMENT '검색조건',
  `CONDITION_TYPE` longtext DEFAULT NULL COMMENT '통전문 OR 파싱조건 구분값',
  `RESPONSE_TYPE` longtext DEFAULT NULL COMMENT '정상 OR 에러 구분 값',
  `SYSTEM_HEADER` longtext DEFAULT NULL COMMENT '채널 헤더',
  `BUSINESS_HEADER` longtext DEFAULT NULL COMMENT '제휴 헤더',
  `ACTIVE_YN` char(1) DEFAULT NULL COMMENT '통전문끼리는 택1, 파싱조건 끼리는 다중선택 가능',
  `HMAC_YN` char(1) DEFAULT NULL COMMENT 'HMAC 여부',
  `SWAGGER_YN` char(1) DEFAULT NULL COMMENT 'SWAGGER 여부',
  `RECORD_STATE` decimal(10,0) DEFAULT NULL COMMENT '레코드 상태(0: 정상, 9: 삭제)',
  `REG_USER` varchar(50) DEFAULT NULL COMMENT '등록자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `MOD_USER` varchar(50) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `STATIC_RESP` longtext DEFAULT NULL COMMENT '대응답',
  `JSONSTRING_YN` char(1) DEFAULT NULL COMMENT '대응답 BODY가 문자열 그 자체로 저장되는지 여부',
  PRIMARY KEY (`API_STATIC_RESP_ID`,`API_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 대응답 데이터';

-- dbpoap.api_static_resp_info definition

CREATE TABLE `api_static_resp_info` (
  `STATIC_RESP_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `API_ID` varchar(255) NOT NULL COMMENT 'API ID',
  `STATIC_RESP_TYPE` char(1) NOT NULL COMMENT '대응답 타입(O: OFF, D: DEFAULT, C: CONDITION)',
  `RECORD_STATE` decimal(10,0) DEFAULT NULL COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`STATIC_RESP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 대응답 정보';

-- dbpoap.api_testbed_layout definition

CREATE TABLE `api_testbed_layout` (
  `API_TESTBED_LAYOUT_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `API_CODE` varchar(50) DEFAULT NULL COMMENT 'API CODE',
  `LAYOUT_TYPE` varchar(5) DEFAULT NULL COMMENT '레이아웃 타입',
  `SEQ` decimal(5,0) DEFAULT NULL COMMENT '순서',
  `KEY` varchar(255) DEFAULT NULL COMMENT '키',
  `TYPE` varchar(10) DEFAULT NULL COMMENT '데이터 유형',
  `NAME` varchar(255) DEFAULT NULL COMMENT '한글명',
  `LENGTH` decimal(10,0) DEFAULT NULL COMMENT '길이',
  `ARRAY_YN` char(1) DEFAULT NULL COMMENT 'ARRAY구분',
  `ARRAY_CNT` varchar(50) DEFAULT NULL COMMENT '반복 횟수 (0 | 1 | 참조컬럼)',
  `ATTR` varchar(10) DEFAULT NULL COMMENT '속성(P:PK, T:PK+SEQUENCE, S: SEQUENCE, M: 다국어)',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `PARENT_SEQ` varchar(36) DEFAULT NULL COMMENT '부모 순서번호',
  `REQUIRED_YN` char(1) DEFAULT NULL COMMENT '필수 여부',
  `DESCRIPTION` varchar(2000) DEFAULT NULL COMMENT 'API 설명',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  PRIMARY KEY (`API_TESTBED_LAYOUT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API LAYOUT I/O 관리';

-- dbpoap.approval definition

CREATE TABLE `approval` (
  `APPROVAL_ID` varchar(100) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `APPROVAL_TYPE` varchar(100) DEFAULT NULL COMMENT '승인 유형',
  `TARGET_ID` varchar(100) DEFAULT NULL COMMENT '대상 ID',
  `USER_ID` varchar(100) DEFAULT NULL COMMENT '사용자ID',
  `PARTNER_ID` varchar(100) DEFAULT NULL COMMENT '파트너 ID',
  `PARENT_ID` varchar(100) DEFAULT NULL COMMENT '부모 승인 ID',
  `ORGANIZATION_ID` varchar(100) DEFAULT NULL COMMENT '기관 ID',
  `TITLE` varchar(100) DEFAULT NULL COMMENT '제목',
  `DECISION` varchar(100) DEFAULT NULL COMMENT '결정',
  `APPROVAL_STATE` varchar(100) DEFAULT NULL COMMENT '상태',
  `DETAIL_COMMENT` varchar(100) DEFAULT NULL COMMENT '메시지',
  `TYPE` varchar(100) NOT NULL COMMENT '타입 (1: 등록, 2: 삭제, 3: 변경)',
  `RECORD_STATE` varchar(100) DEFAULT '0' COMMENT '레코드 상태',
  `REG_USER` varchar(100) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` varchar(100) DEFAULT NULL COMMENT '생성일시',
  `MOD_USER` varchar(100) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` varchar(100) DEFAULT NULL COMMENT '수정일시',
  `TARGET_REV` varchar(100) DEFAULT '0' COMMENT '대상 서비스 버전',
  PRIMARY KEY (`APPROVAL_ID`),
  KEY `APPROVAL_FK` (`ORGANIZATION_ID`) USING BTREE,
  KEY `APPROVAL_FK_1` (`PARENT_ID`) USING BTREE,
  KEY `APPROVAL_FK_2` (`PARTNER_ID`) USING BTREE,
  KEY `APPROVAL_FK_3` (`USER_ID`) USING BTREE,
  CONSTRAINT `APPROVAL_FK` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`),
  CONSTRAINT `APPROVAL_FK_1` FOREIGN KEY (`PARENT_ID`) REFERENCES `approval` (`APPROVAL_ID`),
  CONSTRAINT `APPROVAL_FK_2` FOREIGN KEY (`PARTNER_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`),
  CONSTRAINT `APPROVAL_FK_3` FOREIGN KEY (`USER_ID`) REFERENCES `user_info` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='승인';

-- dbpoap.approval_approver definition

CREATE TABLE `approval_approver` (
  `USER_ID` varchar(36) NOT NULL COMMENT '사용자ID',
  `APPROVAL_ID` varchar(36) NOT NULL COMMENT '승인 ID',
  `POSITION` decimal(38,0) NOT NULL COMMENT '승인 순서',
  `DECISION` varchar(20) DEFAULT NULL COMMENT '결정',
  `STATUS` varchar(20) DEFAULT NULL COMMENT '상태',
  `DETAIL_COMMENT` longtext DEFAULT NULL COMMENT '승인 메시지',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일시',
  PRIMARY KEY (`APPROVAL_ID`,`USER_ID`),
  KEY `APPROVAL_APPROVER_FK_1` (`USER_ID`) USING BTREE,
  CONSTRAINT `APPROVAL_APPROVER_FK` FOREIGN KEY (`APPROVAL_ID`) REFERENCES `approval` (`APPROVAL_ID`),
  CONSTRAINT `APPROVAL_APPROVER_FK_1` FOREIGN KEY (`USER_ID`) REFERENCES `user_info` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='승인 승인자 목록';

-- dbpoap.approval_line definition

CREATE TABLE `approval_line` (
  `APPROVAL_LINE_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관ID',
  `LINE_TYPE` varchar(255) DEFAULT NULL COMMENT '유형',
  `LINE_NAME` varchar(255) DEFAULT NULL COMMENT '이름',
  `USE_YN` char(1) DEFAULT 'Y' COMMENT '사용여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일시',
  PRIMARY KEY (`APPROVAL_LINE_ID`),
  KEY `APPROVAL_LINE_FK` (`ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `APPROVAL_LINE_FK` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='승인라인';


-- dbpoap.approval_line_user definition

CREATE TABLE `approval_line_user` (
  `APPROVAL_LINE_ID` varchar(100) NOT NULL COMMENT '승인라인 ID',
  `USER_ID` varchar(100) NOT NULL COMMENT '사용자ID',
  `POSITION` varchar(100) NOT NULL COMMENT '순서',
  `RECORD_STATE` varchar(100) DEFAULT '0' COMMENT '레코드 상태',
  PRIMARY KEY (`APPROVAL_LINE_ID`,`USER_ID`),
  KEY `APPROVAL_LINE_USER_FK_1` (`USER_ID`) USING BTREE,
  CONSTRAINT `APPROVAL_LINE_USER_FK` FOREIGN KEY (`APPROVAL_LINE_ID`) REFERENCES `approval_line` (`APPROVAL_LINE_ID`),
  CONSTRAINT `APPROVAL_LINE_USER_FK_1` FOREIGN KEY (`USER_ID`) REFERENCES `user_info` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='승인 라인';

-- dbpoap.app_api_mapping definition

CREATE TABLE `app_api_mapping` (
  `APP_API_MAPPING_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `API_POLICY_ID` varchar(36) DEFAULT NULL COMMENT '사용정책 ID',
  `APP_ID` varchar(36) NOT NULL COMMENT '앱 ID',
  `API_ID` varchar(36) NOT NULL COMMENT 'API ID',
  `RECORD_STATE` decimal(1,0) DEFAULT NULL COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT current_timestamp() COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `CA_PROXY` char(1) DEFAULT 'N' COMMENT 'CA우회여부',
  PRIMARY KEY (`APP_API_MAPPING_ID`),
  KEY `APP_API_MAPPING_FK` (`API_ID`) USING BTREE,
  KEY `APP_API_MAPPING_FK_1` (`API_POLICY_ID`) USING BTREE,
  KEY `APP_API_MAPPING_FK_2` (`APP_ID`) USING BTREE,
  CONSTRAINT `APP_API_MAPPING_FK` FOREIGN KEY (`API_ID`) REFERENCES `api_info` (`API_ID`),
  CONSTRAINT `APP_API_MAPPING_FK_1` FOREIGN KEY (`API_POLICY_ID`) REFERENCES `api_policy` (`API_POLICY_ID`),
  CONSTRAINT `APP_API_MAPPING_FK_2` FOREIGN KEY (`APP_ID`) REFERENCES `app_info` (`APP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='앱 API 맵핑';

-- dbpoap.app_api_mapping_aud definition

CREATE TABLE `app_api_mapping_aud` (
  `APP_API_MAPPING_ID` varchar(100) NOT NULL COMMENT 'ID',
  `REV` varchar(100) NOT NULL DEFAULT '0' COMMENT '버전',
  `REVTYPE` varchar(100) DEFAULT NULL COMMENT '버전타입(C:create, U:update, D:delete)',
  `API_POLICY_ID` varchar(100) DEFAULT NULL COMMENT '사용정책 ID',
  `APP_ID` varchar(100) NOT NULL COMMENT '앱 ID',
  `API_ID` varchar(100) NOT NULL COMMENT 'API ID',
  `RECORD_STATE` varchar(100) DEFAULT '0' COMMENT '레코드 상태',
  `REG_USER` varchar(100) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` varchar(100) DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(100) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` varchar(100) DEFAULT NULL COMMENT '최종 수정일',
  `CA_PROXY` varchar(100) DEFAULT NULL COMMENT 'CA우회여부',
  PRIMARY KEY (`APP_API_MAPPING_ID`,`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='앱 API 맵핑 이력';

-- dbpoap.app_info definition

CREATE TABLE `app_info` (
  `APP_ID` varchar(36) NOT NULL COMMENT 'ID',
  `APP_KEY` varchar(255) DEFAULT NULL COMMENT '앱키',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관ID',
  `WHITE_LIST` varchar(4000) DEFAULT NULL COMMENT '화이트 리스트',
  `VERSION` decimal(10,0) DEFAULT 0 COMMENT '버전',
  `STATUS` varchar(255) DEFAULT NULL COMMENT '상태',
  `DETAIL_STATUS` varchar(255) DEFAULT NULL COMMENT '세부 상태',
  `O_AUTH_TYPE` varchar(255) DEFAULT NULL COMMENT 'oAuth 타입',
  `O_AUTH_SCOPE` varchar(255) DEFAULT NULL COMMENT 'oAuth 범위',
  `O_AUTH_CALLBACK_URL` longtext DEFAULT NULL COMMENT 'oAuth 인증 콜백',
  `NAME` varchar(255) NOT NULL COMMENT '이름',
  `SECRET_KEY` varchar(255) DEFAULT NULL COMMENT '시크릿 키',
  `DESCRIPTION` longtext DEFAULT NULL COMMENT '한글명',
  `TARGET_SERVER` varchar(255) DEFAULT 'D' COMMENT '연계서버 구분코드',
  `PAYMENT_TYPE` varchar(255) DEFAULT NULL COMMENT '출금유형',
  `BANK_NAME` varchar(255) DEFAULT NULL COMMENT '은행명',
  `ACCOUNT_NUMBER` varchar(255) DEFAULT NULL COMMENT '계좌번호',
  `PAYMENT_CYCLE` varchar(255) DEFAULT NULL COMMENT '출금주기',
  `DEPOSITOR` varchar(255) DEFAULT NULL COMMENT '예금주',
  `DEPOSIT_ACCOUNT` varchar(255) DEFAULT NULL COMMENT '입금계정',
  `MANAGEMENT_BRANCH` varchar(255) DEFAULT NULL COMMENT '관리점',
  `CUSTOM_NO` varchar(255) DEFAULT NULL COMMENT 'customNo',
  `RETURN_DEPOSITOR` varchar(255) DEFAULT NULL COMMENT '(반환)예금주',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT current_timestamp() COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `OAPI_SYS_DV_CD` varchar(2) DEFAULT NULL COMMENT '오픈 API 시스템 구분코드',
  PRIMARY KEY (`APP_ID`),
  KEY `APP_INFO_FK` (`ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `APP_INFO_FK` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='APP 정보';




-- dbpoap.APP_INFO_AUD definition

CREATE TABLE `APP_INFO_AUD` (
  `APP_ID` varchar(36) NOT NULL COMMENT 'ID',
  `REV` decimal(20,0) NOT NULL COMMENT '버전',
  `REVTYPE` char(1) DEFAULT NULL COMMENT '버전타입(C:create, U:update, D:delete)',
  `APP_KEY` varchar(255) DEFAULT NULL COMMENT '앱 키',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관 ID',
  `WHITE_LIST` varchar(4000) DEFAULT NULL COMMENT '화이트 리스트',
  `VERSION` decimal(10,0) DEFAULT NULL COMMENT '버전',
  `STATUS` varchar(255) DEFAULT NULL COMMENT '상태',
  `DETAIL_STATUS` varchar(255) DEFAULT NULL COMMENT '세부 상태',
  `O_AUTH_TYPE` varchar(255) DEFAULT NULL COMMENT 'oAuth 타입',
  `O_AUTH_SCOPE` varchar(255) DEFAULT NULL COMMENT 'oAuth 범위',
  `O_AUTH_CALLBACK_URL` longtext DEFAULT NULL COMMENT 'oAuth 인증 콜백',
  `NAME` varchar(255) NOT NULL COMMENT '이름',
  `SECRET_KEY` varchar(255) DEFAULT NULL COMMENT '시크릿 키',
  `DESCRIPTION` longtext DEFAULT NULL COMMENT '한글명',
  `TARGET_SERVER` varchar(255) DEFAULT NULL COMMENT '연계서버 구분코드',
  `PAYMENT_TYPE` varchar(255) DEFAULT NULL COMMENT '출금유형',
  `BANK_NAME` varchar(255) DEFAULT NULL COMMENT '은행명',
  `ACCOUNT_NUMBER` varchar(255) DEFAULT NULL COMMENT '계좌번호',
  `PAYMENT_CYCLE` varchar(255) DEFAULT NULL COMMENT '출금주기',
  `DEPOSITOR` varchar(255) DEFAULT NULL COMMENT '예금주',
  `DEPOSIT_ACCOUNT` varchar(255) DEFAULT NULL COMMENT '입금계정',
  `MANAGEMENT_BRANCH` varchar(255) DEFAULT NULL COMMENT '관리점',
  `CUSTOM_NO` varchar(255) DEFAULT NULL COMMENT 'customNo',
  `RETURN_DEPOSITOR` varchar(255) DEFAULT NULL COMMENT '반환)예금주',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `OAPI_SYS_DV_CD` varchar(2) DEFAULT NULL COMMENT '오픈API시스템구분코드',
  PRIMARY KEY (`APP_ID`,`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='APP 정보 이력';




















-- dbpoap.ATTACH_FILE definition

CREATE TABLE `ATTACH_FILE` (
  `ATTACH_FILE_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `ATTACH_FILE` blob DEFAULT NULL,
  `ATTACH_TYPE` varchar(255) DEFAULT NULL COMMENT '첨부파일 유형',
  `FILE_NAME` varchar(255) DEFAULT NULL COMMENT '파일 이름',
  `TARGET_ID` varchar(255) DEFAULT NULL COMMENT '대상ID',
  `FILE_SIZE` decimal(10,0) DEFAULT NULL COMMENT '파일크기',
  `RECORD_STATE` decimal(10,0) DEFAULT NULL COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `JOB_ID` varchar(36) DEFAULT NULL COMMENT '무해화 파일ID',
  `STATUS` varchar(10) DEFAULT NULL COMMENT '파일 등록 상태',
  PRIMARY KEY (`ATTACH_FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='첨부파일';

-- dbpoap.BATCH_HISTORY definition

CREATE TABLE `BATCH_HISTORY` (
  `BATCH_HISTORY_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT '배치 이력 ID',
  `BATCH_ID` varchar(255) NOT NULL COMMENT '배치 명',
  `NUMBER_OF_PROCESSING` decimal(10,0) NOT NULL COMMENT '실행 건수',
  `BATCH_START_DTTM` timestamp NULL DEFAULT NULL COMMENT '배치 실행 시작일시',
  `BATCH_END_DTTM` timestamp NULL DEFAULT NULL COMMENT '배치 실행 종료일시',
  `BATCH_RESULT` varchar(255) DEFAULT NULL COMMENT '배치 결과',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록 일자',
  `BATCH_ERR_MSG` varchar(4000) DEFAULT NULL COMMENT '배치 에러 메세지',
  `NUMBER_OF_ERROR` decimal(10,0) DEFAULT NULL COMMENT '에러 건수',
  `BATCH_PARAMS` varchar(500) DEFAULT NULL COMMENT '배치 실행 조건',
  `JOB_ID` varchar(10) DEFAULT NULL COMMENT 'JOB ID',
  PRIMARY KEY (`BATCH_HISTORY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='배치 로그';

-- dbpoap.bill definition

CREATE TABLE `bill` (
  `BILL_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '최초 금액',
  `DISCOUNT_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '할인 금액',
  `CHANGE_REASON` varchar(400) DEFAULT NULL COMMENT '변경 사유',
  `DUE_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '청구 금액',
  `DUE_DATE` timestamp NULL DEFAULT NULL COMMENT '기한',
  `TYPE` varchar(255) DEFAULT NULL COMMENT '청구서 타입',
  `PAYMENT_TYPE` varchar(255) DEFAULT NULL COMMENT '출금유형',
  `PAID_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '지급 금액',
  `PAID_DATE` timestamp NULL DEFAULT NULL COMMENT '지급 일자',
  `CHARGE_MONTH` varchar(6) DEFAULT NULL COMMENT '청구월',
  `PROV_ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '제공 기관 ID',
  `USER_ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '사용자 ID',
  `APP_ID` varchar(36) DEFAULT NULL COMMENT 'APP ID',
  `ACCOUNT_NO` varchar(255) DEFAULT NULL COMMENT '출금계좌',
  `DEPOSIT_ACCOUNT` varchar(255) DEFAULT NULL COMMENT '입금계정',
  `MANAGEMENT_BRANCH` varchar(255) DEFAULT NULL COMMENT '관리점',
  `CUSTOM_NUMBER` varchar(255) DEFAULT NULL COMMENT 'customNO',
  `PROVIDER_CHECK_YN` char(1) DEFAULT NULL COMMENT '청구 확정',
  `PROVIDER_CHECK_DATE` date DEFAULT NULL COMMENT '청구 확정일-청구 확정시 자동입력',
  `PAYMENT_YN` char(1) DEFAULT NULL COMMENT '징수 여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `PAYMENT_DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '출금 관련 설명',
  PRIMARY KEY (`BILL_ID`),
  KEY `NewTable_1_FK` (`APP_ID`) USING BTREE,
  KEY `NewTable_1_FK_1` (`PROV_ORGANIZATION_ID`) USING BTREE,
  KEY `NewTable_1_FK_2` (`USER_ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `NewTable_1_FK` FOREIGN KEY (`APP_ID`) REFERENCES `app_info` (`APP_ID`),
  CONSTRAINT `NewTable_1_FK_1` FOREIGN KEY (`PROV_ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`),
  CONSTRAINT `NewTable_1_FK_2` FOREIGN KEY (`USER_ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='청구서';

-- dbpoap.billing_base_data definition

CREATE TABLE `billing_base_data` (
  `APP_ID` varchar(255) NOT NULL COMMENT '앱 ID',
  `API_ID` varchar(255) NOT NULL COMMENT 'API ID',
  `ORGANIZATION_ID` varchar(36) NOT NULL COMMENT '기관 ID',
  `API_NAME` varchar(255) DEFAULT NULL COMMENT 'API 명',
  `BILLING_POLICY_ID` varchar(36) DEFAULT NULL COMMENT '과금 정책 ID',
  `ORGANIZATION_NAME` varchar(50) DEFAULT NULL COMMENT '기관 명',
  `APP_NAME` varchar(255) DEFAULT NULL COMMENT '입 이름',
  `DISCOUNT_TYPE` varchar(255) DEFAULT NULL COMMENT '과금용_할인구분',
  `DISCOUNT_DETAIL` decimal(19,2) DEFAULT NULL COMMENT '과금용_할인상세(적용금액 등)',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`API_ID`,`APP_ID`,`ORGANIZATION_ID`),
  KEY `BILLING_BASE_DATA_API_ID_IDX` (`API_ID`,`APP_ID`,`ORGANIZATION_ID`) USING BTREE,
  KEY `BILLING_BASE_DATA_FK` (`BILLING_POLICY_ID`) USING BTREE,
  CONSTRAINT `BILLING_BASE_DATA_FK` FOREIGN KEY (`BILLING_POLICY_ID`) REFERENCES `billing_policy` (`BILLING_POLICY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='과금 기초 데이터';

-- dbpoap.billing_charge definition

CREATE TABLE `billing_charge` (
  `API_ID` varchar(255) NOT NULL COMMENT 'API ID',
  `CHARGE_MONTH` varchar(255) NOT NULL COMMENT '과금 월',
  `ORGANIZATION_ID` varchar(255) NOT NULL COMMENT '기관 ID',
  `AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '최종 금액',
  `API_NAME` varchar(255) DEFAULT NULL COMMENT 'API 명',
  `COMPLETED_COUNT` bigint(20) DEFAULT NULL COMMENT '완료 횟수',
  `ORGANIZATION_NAME` varchar(255) DEFAULT NULL COMMENT '기관 명',
  `PROV_ORGANIZATION_ID` varchar(255) DEFAULT NULL COMMENT '제공 기관 ID',
  `PROV_ORGANIZATION_NAME` varchar(255) DEFAULT NULL COMMENT '제공 기관명',
  `BILLING_POLICY_ID` varchar(36) DEFAULT NULL COMMENT '과금 정책 ID',
  PRIMARY KEY (`API_ID`,`CHARGE_MONTH`,`ORGANIZATION_ID`),
  KEY `FK_BC_BPID_BP_ID` (`BILLING_POLICY_ID`) USING BTREE,
  CONSTRAINT `FK_BC_BPID_BP_ID` FOREIGN KEY (`BILLING_POLICY_ID`) REFERENCES `billing_policy` (`BILLING_POLICY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='과금';

-- dbpoap.billing_data_history definition

CREATE TABLE `billing_data_history` (
  `BILLING_BASE_DATA_ORGANIZATION_ID` varchar(36) NOT NULL COMMENT '청구 기초 데이터 기관 ID',
  `BILLING_BASE_DATA_APP_ID` varchar(255) NOT NULL COMMENT '청구 기초 데이터 앱 ID',
  `BILLING_BASE_DATA_API_ID` varchar(255) NOT NULL COMMENT '청구 기초 데이터 API ID',
  `TIMESLICE` timestamp(6) NOT NULL COMMENT '시간 구간',
  `BILLING_POLICY_ID` varchar(36) DEFAULT NULL COMMENT '과금 정책 ID',
  `COMPLETED_COUNT` bigint(20) DEFAULT NULL COMMENT '완료 횟수',
  `AUTHORIZED_COUNT` bigint(20) DEFAULT NULL COMMENT '인증 횟수',
  `ATTEMPTED_COUNT` bigint(20) DEFAULT NULL COMMENT '시도 횟수',
  PRIMARY KEY (`BILLING_BASE_DATA_API_ID`,`BILLING_BASE_DATA_APP_ID`,`BILLING_BASE_DATA_ORGANIZATION_ID`,`TIMESLICE`),
  KEY `FK_BDH_BPID_BP_BPID` (`BILLING_POLICY_ID`) USING BTREE,
  CONSTRAINT `FK_BDH_BBB_BBD_AAP` FOREIGN KEY (`BILLING_BASE_DATA_API_ID`, `BILLING_BASE_DATA_APP_ID`, `BILLING_BASE_DATA_ORGANIZATION_ID`) REFERENCES `billing_base_data` (`API_ID`, `APP_ID`, `ORGANIZATION_ID`),
  CONSTRAINT `FK_BDH_BPID_BP_BPID` FOREIGN KEY (`BILLING_POLICY_ID`) REFERENCES `billing_policy` (`BILLING_POLICY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='과금 이력';

-- dbpoap.billing_policy definition

CREATE TABLE `billing_policy` (
  `BILLING_POLICY_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `CHARGE_PER_HIT` decimal(19,2) DEFAULT NULL COMMENT '요청당 과금',
  `NAME` varchar(255) DEFAULT NULL COMMENT '이름',
  `LEAST_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '최소 금액',
  `BASIC_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '기본요금',
  `BASIC_HIT` decimal(17,0) DEFAULT NULL COMMENT '기본건수',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '소유 기관 ID',
  `REWARD` decimal(1,0) DEFAULT NULL COMMENT '보상',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`BILLING_POLICY_ID`),
  KEY `BILLING_POLICY_FK` (`ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `BILLING_POLICY_FK` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='과금 정책';

-- dbpoap.bill_adjust definition

CREATE TABLE `bill_adjust` (
  `BILL_ADJUST_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `ADJUST_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '변경 금액',
  `ORIGINAL_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '변경 전 금액',
  `CHANGE_REASON` varchar(400) DEFAULT NULL COMMENT '변경 사유',
  `BILL_ID` varchar(36) DEFAULT NULL COMMENT '청구서',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `BILL_DETAIL_ADJUST_ID` varchar(50) DEFAULT NULL COMMENT '과금내역 상세 조정 ID',
  `BILL_DETAIL_ID` varchar(50) DEFAULT NULL COMMENT 'BILL DETAIL ID',
  `BEFORE_AMOUNT` decimal(38,0) DEFAULT NULL COMMENT '변경 전 금액',
  PRIMARY KEY (`BILL_ADJUST_ID`),
  KEY `BILL_ADJUST_FK` (`BILL_ID`) USING BTREE,
  CONSTRAINT `BILL_ADJUST_FK` FOREIGN KEY (`BILL_ID`) REFERENCES `bill` (`BILL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='청구서 조정 이력';

-- dbpoap.bill_detail definition

CREATE TABLE `bill_detail` (
  `BILL_DETAIL_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `BILL_ID` varchar(36) DEFAULT NULL COMMENT 'BILL ID',
  `API_ID` varchar(36) DEFAULT NULL COMMENT 'API ID',
  `COMPLETED_COUNT` decimal(19,0) DEFAULT NULL COMMENT '이용건수',
  `BASIC_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '기본요금',
  `BASIC_HIT` decimal(19,0) DEFAULT NULL COMMENT '기본건수',
  `CHARGE_PER_HIT` decimal(19,2) DEFAULT NULL COMMENT '초과건당요금',
  `DISCOUNT_TYPE` varchar(255) DEFAULT NULL COMMENT '할인구분',
  `DISCOUNT_DETAIL` decimal(19,2) DEFAULT NULL COMMENT '할인상세(적용금액 등)',
  `ORIGIN_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '수수료(최초)',
  `AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '확정수수료',
  `CHANGE_REASON` varchar(400) DEFAULT NULL COMMENT '변경사유',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`BILL_DETAIL_ID`),
  KEY `BILL_DETAIL_FK` (`API_ID`) USING BTREE,
  KEY `BILL_DETAIL_FK_1` (`BILL_ID`) USING BTREE,
  CONSTRAINT `BILL_DETAIL_FK` FOREIGN KEY (`API_ID`) REFERENCES `api_info` (`API_ID`),
  CONSTRAINT `BILL_DETAIL_FK_1` FOREIGN KEY (`BILL_ID`) REFERENCES `bill` (`BILL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='과금내역 상세';

-- dbpoap.bill_detail_adjust definition

CREATE TABLE `bill_detail_adjust` (
  `BILL_DETAIL_ADJUST_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `BILL_DETAIL_ID` varchar(36) DEFAULT NULL COMMENT 'BILL DETAIL ID',
  `ADJUST_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '변경 금액',
  `BEFORE_AMOUNT` decimal(19,2) DEFAULT NULL COMMENT '변경 전 금액',
  `CHANGE_REASON` varchar(400) DEFAULT NULL COMMENT '변경사유',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`BILL_DETAIL_ADJUST_ID`),
  KEY `BILL_DETAIL_ADJUST_FK` (`BILL_DETAIL_ID`) USING BTREE,
  CONSTRAINT `BILL_DETAIL_ADJUST_FK` FOREIGN KEY (`BILL_DETAIL_ID`) REFERENCES `bill_detail` (`BILL_DETAIL_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='과금내역 상세 조정 이력';

-- dbpoap.certificate_entity definition

CREATE TABLE `certificate_entity` (
  `CERTIFICATE_ENTITY_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT '인증서 하위 객체 ID',
  `CERTIFICATE_ID` varchar(36) NOT NULL COMMENT '인증서 ID',
  `ORGANIZATION_ID` varchar(36) NOT NULL COMMENT '제공기관 ID',
  `DOMAIN` varchar(255) DEFAULT NULL COMMENT '도메인',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태 (0: 정상, 9: 삭제)',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`CERTIFICATE_ENTITY_ID`),
  KEY `CERTIFICATE_ENTITY_FK` (`CERTIFICATE_ID`) USING BTREE,
  KEY `CERTIFICATE_ENTITY_FK_1` (`ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `CERTIFICATE_ENTITY_FK` FOREIGN KEY (`CERTIFICATE_ID`) REFERENCES `certificate_info` (`CERTIFICATE_ID`),
  CONSTRAINT `CERTIFICATE_ENTITY_FK_1` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='인증서 하위 도메인 정보';

-- dbpoap.certificate_info definition

CREATE TABLE `certificate_info` (
  `CERTIFICATE_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT '인증서 ID',
  `POD_ID` varchar(36) NOT NULL COMMENT 'POD ID',
  `TYPE` varchar(36) NOT NULL COMMENT '구분 (SERVER, CHAIN, ENTITY)',
  `DOMAIN` varchar(255) DEFAULT NULL COMMENT '도메인',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관 ID (TYPE이 ENTITY일 경우에만 입력)',
  `ALIAS` varchar(255) DEFAULT NULL COMMENT '별칭 (중복 불가)',
  `OWNER` varchar(255) DEFAULT NULL COMMENT '소유자',
  `ISSUER` varchar(255) DEFAULT NULL COMMENT '발행자',
  `SERIAL_NUMBER` varchar(50) DEFAULT NULL COMMENT '일련번호',
  `START_DATE` date DEFAULT NULL COMMENT '인증서 시작일',
  `EXPIRED_DATE` date DEFAULT NULL COMMENT '인증서 만료일',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태 (0: 정상, 9: 삭제)',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `PARENT_ID` varchar(36) DEFAULT NULL COMMENT 'ROOT 인증서 ID',
  PRIMARY KEY (`CERTIFICATE_ID`),
  KEY `CERTIFICATE_INFO_FK` (`ORGANIZATION_ID`) USING BTREE,
  KEY `CERTIFICATE_INFO_FK_1` (`POD_ID`) USING BTREE,
  CONSTRAINT `CERTIFICATE_INFO_FK` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`),
  CONSTRAINT `CERTIFICATE_INFO_FK_1` FOREIGN KEY (`POD_ID`) REFERENCES `pod_info` (`POD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='인증서 정보';

-- dbpoap.certificate_unregistered definition

CREATE TABLE `certificate_unregistered` (
  `POD_ID` varchar(36) DEFAULT NULL COMMENT '대상서버',
  `ISSUER` varchar(255) DEFAULT NULL COMMENT '발행자',
  `DOMAIN` varchar(50) DEFAULT NULL COMMENT '도메인',
  `SERIAL_NUMBER` varchar(255) DEFAULT NULL COMMENT '일련번호',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `COMMON_NAME` varchar(50) DEFAULT NULL COMMENT '공통명'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='인증서 거래 허용 대기 리스트';

-- dbpoap.code_group_info definition

CREATE TABLE `code_group_info` (
  `CODE_GROUP_KEY` varchar(50) NOT NULL COMMENT '코드 그룹 키',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '한글명',
  `SORT` decimal(10,0) DEFAULT NULL COMMENT '순서',
  `USE_YN` char(1) DEFAULT 'Y' COMMENT '사용구분',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일시',
  PRIMARY KEY (`CODE_GROUP_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='공통 코드 그룹';

-- dbpoap.code_info definition

CREATE TABLE `code_info` (
  `CODE_KEY` varchar(50) NOT NULL COMMENT '코드 키',
  `CODE_GROUP_KEY` varchar(50) NOT NULL COMMENT '코드 그룹 키',
  `VALUE` varchar(255) NOT NULL COMMENT '값',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '한글명',
  `SORT` decimal(10,0) DEFAULT NULL COMMENT '순서',
  `USE_YN` char(1) DEFAULT 'Y' COMMENT '사용구분',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일시',
  PRIMARY KEY (`CODE_KEY`,`CODE_GROUP_KEY`),
  KEY `CODE_INFO_FK` (`CODE_GROUP_KEY`) USING BTREE,
  CONSTRAINT `CODE_INFO_FK` FOREIGN KEY (`CODE_GROUP_KEY`) REFERENCES `code_group_info` (`CODE_GROUP_KEY`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='공통 코드';

-- dbpoap.commit_deploy definition

CREATE TABLE `commit_deploy` (
  `COMMIT_DEPLOY_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `COMMIT_SERVICE_ID` int(11) NOT NULL COMMENT '커밋 서비스 ID',
  `DEPLOY_STATE` varchar(20) DEFAULT 'WAIT' COMMENT '배포상태',
  `DEPLOY_DTTM` timestamp NULL DEFAULT NULL COMMENT '배포일시',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  PRIMARY KEY (`COMMIT_DEPLOY_ID`),
  KEY `COMMIT_DEPLOY_FK` (`COMMIT_SERVICE_ID`) USING BTREE,
  CONSTRAINT `COMMIT_DEPLOY_FK` FOREIGN KEY (`COMMIT_SERVICE_ID`) REFERENCES `commit_service_info` (`COMMIT_SERVICE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='승인완료된 COMMIT 서비스의 배포관리';

-- dbpoap.commit_info definition

CREATE TABLE `commit_info` (
  `COMMIT_ID` varchar(50) NOT NULL COMMENT 'ID',
  `COMMIT_MSG` varchar(200) DEFAULT NULL COMMENT '커밋 메시지',
  `DEPLOY_STATE` varchar(20) DEFAULT 'WAIT' COMMENT '배포상태',
  `DEPLOY_USER` varchar(36) DEFAULT NULL COMMENT '배포자ID',
  `DEPLOY_DTTM` timestamp NULL DEFAULT NULL COMMENT '배포일시',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  `DETAIL_STATUS` varchar(255) DEFAULT NULL COMMENT '승인상태',
  PRIMARY KEY (`COMMIT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='커밋된 정보';

-- dbpoap.commit_service_info definition

CREATE TABLE `commit_service_info` (
  `COMMIT_SERVICE_ID` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `COMMIT_ID` varchar(50) NOT NULL COMMENT '커밋 ID',
  `SERVICE_TYPE` varchar(20) NOT NULL COMMENT '서비스 타입',
  `SERVICE_CODE` varchar(50) NOT NULL COMMENT '서비스코드',
  `DEPLOY_STATE` varchar(20) DEFAULT NULL COMMENT '배포상태',
  `DEPLOY_DTTM` timestamp NULL DEFAULT NULL COMMENT '배포일시',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  PRIMARY KEY (`COMMIT_SERVICE_ID`),
  KEY `COMMIT_SERVICE_INFO_FK` (`COMMIT_ID`) USING BTREE,
  CONSTRAINT `COMMIT_SERVICE_INFO_FK` FOREIGN KEY (`COMMIT_ID`) REFERENCES `commit_info` (`COMMIT_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='커밋된 API/FILTER 정보';

-- dbpoap.destination_info definition

CREATE TABLE `destination_info` (
  `DESTINATION_ID` varchar(36) NOT NULL COMMENT 'ID',
  `ORGANIZATION_ID` varchar(36) NOT NULL COMMENT '기관ID',
  `DESTINATION_NAME` varchar(255) NOT NULL COMMENT '목적지명',
  `DESTINATION_CODE` varchar(255) NOT NULL COMMENT '목적지 코드',
  `HOST` varchar(255) NOT NULL COMMENT '호스트',
  `PORT` bigint(20) NOT NULL COMMENT '포트',
  `NETWORK_TYPE` varchar(20) NOT NULL COMMENT '망구분 (DEDICATED, PUBLIC)',
  `PROTOCOL_TYPE` varchar(20) NOT NULL COMMENT '통신유형 (SFTP, HTTP)',
  `SFTP_AUTH_TYPE` varchar(20) DEFAULT NULL COMMENT 'SFTP 인증방식 (IP_PWD, KEY)',
  `SFTP_ID` varchar(255) DEFAULT NULL COMMENT 'SFTP ID',
  `SFTP_PWD` varchar(255) DEFAULT NULL COMMENT 'SFTP PWD',
  `SFTP_PUBLIC_KEY` varchar(2000) DEFAULT NULL COMMENT 'SFTP PUBLIC KEY',
  `SFTP_PRIVATE_KEY` varchar(4000) DEFAULT NULL COMMENT 'SFTP PRIVATE KEY',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일시',
  PRIMARY KEY (`DESTINATION_ID`),
  UNIQUE KEY `UK_DESTINATION_CODE` (`DESTINATION_CODE`),
  KEY `IDX_DESTINATION_ORG_ID` (`ORGANIZATION_ID`),
  CONSTRAINT `DESTINATION_INFO_FK` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='목적지 관리';

-- dbpoap.discount_api_policy definition

CREATE TABLE `discount_api_policy` (
  `API_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'API ID',
  `USER_ORGANIZATION_ID` varchar(36) NOT NULL COMMENT '이용기관 ID',
  `PROV_ORGANIZATION_ID` varchar(36) NOT NULL COMMENT '제공기관 ID',
  `DISCOUNT_TYPE` varchar(255) DEFAULT NULL COMMENT '할인구분 - 0 : 없음 / 1: CAP / 2:면제 / 3.정률(%)할인 / 4. 정액(원)할인',
  `DISCOUNT_DETAIL` decimal(19,2) DEFAULT NULL COMMENT '할인상세(적용금액 등)',
  `APPLY_START_DATE` date DEFAULT NULL COMMENT '적용시작월(yyyymmdd)',
  `APPLY_END_DATE` date DEFAULT NULL COMMENT '적용종료월(yyyymmdd)',
  `NEXT_DISCOUNT_TYPE` varchar(255) DEFAULT NULL COMMENT '할인구분 - 0 : 없음 / 1: CAP / 2:면제 / 3.정률(%)할인 / 4. 정액(원)할인',
  `NEXT_DISCOUNT_DETAIL` decimal(19,2) DEFAULT NULL COMMENT '할인상세(적용금액 등)',
  `NEXT_APPLY_START_DATE` date DEFAULT NULL COMMENT '적용시작월(yyyymmdd)',
  `NEXT_APPLY_END_DATE` date DEFAULT NULL COMMENT '적용종료월(yyyymmdd)',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`API_ID`,`USER_ORGANIZATION_ID`,`PROV_ORGANIZATION_ID`),
  KEY `DISCOUNT_API_POLICY_FK_1` (`PROV_ORGANIZATION_ID`) USING BTREE,
  KEY `DISCOUNT_API_POLICY_FK_2` (`USER_ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `DISCOUNT_API_POLICY_FK` FOREIGN KEY (`API_ID`) REFERENCES `api_info` (`API_ID`),
  CONSTRAINT `DISCOUNT_API_POLICY_FK_1` FOREIGN KEY (`PROV_ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`),
  CONSTRAINT `DISCOUNT_API_POLICY_FK_2` FOREIGN KEY (`USER_ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API별 할인 내역 관리';

-- dbpoap.eims_api_info definition

CREATE TABLE `eims_api_info` (
  `EIMS_API_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'API 아이디',
  `EIMS_API_CODE` varchar(50) NOT NULL COMMENT 'API CODE',
  `EIMS_API_NAME` varchar(200) DEFAULT NULL COMMENT 'API 한글명',
  `EIMS_API_URI` varchar(255) DEFAULT NULL COMMENT 'API URI',
  `POD_ID` varchar(50) DEFAULT NULL COMMENT 'POD 코드',
  `EIMS_METHOD` varchar(10) DEFAULT NULL COMMENT '메소드 구분(01:GET, 02:POST, 03:PARM, 04:PUT, 05:DELETE)',
  `EIMS_DATA_TYPE` char(1) DEFAULT NULL COMMENT '전문구분 D(일반전문),B(ByPass)',
  `EIMS_BOUND_TYPE` varchar(10) DEFAULT NULL COMMENT 'Bound타입(01:InBound, 02:OutBound)',
  `EIMS_SCOPE` varchar(50) DEFAULT NULL COMMENT 'SCOPE',
  `EIMS_XML_CONTENT` longtext DEFAULT NULL COMMENT 'XML 내용 저장',
  `EIMS_INTERFACE_ID` varchar(50) DEFAULT NULL COMMENT 'INTERFACE 아이디',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록일',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일',
  `EIMS_BODY_TYPE` varchar(10) DEFAULT NULL COMMENT '전문 BODY 유형',
  `EIMS_PROXY` char(1) DEFAULT NULL COMMENT 'Proxy 여부',
  `EIMS_BASE64_ENCODING_YN` char(1) DEFAULT NULL COMMENT 'base64 변환유형 인코딩(수신)',
  `EIMS_BASE64_DECODING_YN` char(1) DEFAULT NULL COMMENT 'base64 변환유형 디코딩(송신)',
  PRIMARY KEY (`EIMS_API_ID`,`EIMS_API_CODE`),
  KEY `EIMS_API_INFO_FK` (`POD_ID`) USING BTREE,
  CONSTRAINT `EIMS_API_INFO_FK` FOREIGN KEY (`POD_ID`) REFERENCES `pod_info` (`POD_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='EIMS API 정보';

-- dbpoap.file_sanitize_pendding definition

CREATE TABLE `file_sanitize_pendding` (
  `JOB_ID` varchar(36) NOT NULL COMMENT '무해화 대상 파일 ID',
  `TARGET_ID` varchar(255) NOT NULL COMMENT '대상 ID',
  `CODE` decimal(10,0) DEFAULT NULL COMMENT '무해화 요청 응답',
  `ATTACH_TYPE` varchar(255) DEFAULT NULL COMMENT '첨부파일 유형',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '등록자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록일시',
  `LOG_REASON` varchar(6) DEFAULT NULL COMMENT '무해화 완료 상세 코드',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일시',
  `FILE_NAME` varchar(255) DEFAULT NULL COMMENT '첨부파일명'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='대기 목록';

-- dbpoap.filter_group_args definition

CREATE TABLE `filter_group_args` (
  `FILTER_GROUP_ARGS_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `FILTER_GROUP_ID` varchar(36) NOT NULL COMMENT 'FILTER GROUP ID',
  `KEY` varchar(50) NOT NULL COMMENT 'ARGUMENT KEY',
  `LABEL` varchar(255) NOT NULL COMMENT '표시명',
  `TYPE` varchar(255) NOT NULL COMMENT '유형',
  `DEFAULT_VALUE` varchar(255) DEFAULT NULL COMMENT '기본값',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일시',
  PRIMARY KEY (`FILTER_GROUP_ARGS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='FILTER GROUP 파라미터';

-- dbpoap.filter_group_info definition

CREATE TABLE `filter_group_info` (
  `FILTER_GROUP_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `POD_ID` varchar(36) NOT NULL COMMENT 'POD ID',
  `FILTER_GROUP_CODE` varchar(36) NOT NULL COMMENT 'FILTER GROUP CODE',
  `FILTER_GROUP_NAME` varchar(36) NOT NULL COMMENT '파일명',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일',
  PRIMARY KEY (`FILTER_GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='FILTER GROUP 정보';

-- dbpoap.forum_notice_popup definition

CREATE TABLE `forum_notice_popup` (
  `FORUM_NOTICE_POPUP_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `TITLE` varchar(255) NOT NULL COMMENT '제목',
  `CONTENT` longtext DEFAULT NULL COMMENT '게시 내용',
  `LINK_URL` varchar(255) DEFAULT NULL COMMENT '연결 URL',
  `NOTICE_PERIOD` varchar(50) DEFAULT NULL COMMENT '기간 안내',
  `DISPLAY_START_DTTM` timestamp NULL DEFAULT NULL COMMENT '게시 기간 시작일',
  `DISPLAY_END_DTTM` timestamp NULL DEFAULT NULL COMMENT '게시 기간 종료일',
  `PUBLIC_YN` char(1) DEFAULT NULL COMMENT '공개 여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `LINK_TARGET` varchar(10) DEFAULT NULL COMMENT '이동방식구분 (새창: _blank, 현재창: _self)',
  PRIMARY KEY (`FORUM_NOTICE_POPUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='메인 공지 팝업';

-- dbpoap.forum_post definition

CREATE TABLE `forum_post` (
  `FORUM_POST_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `CONTENT` longtext DEFAULT NULL COMMENT '게시 내용',
  `FORUM_TYPE` varchar(36) DEFAULT NULL COMMENT '포럼 ID',
  `PUBLIC_YN` char(1) NOT NULL COMMENT '공개 여부',
  `WRITER_ID` varchar(36) DEFAULT NULL COMMENT '작성자ID',
  `VIEW_COUNT` decimal(10,0) DEFAULT NULL COMMENT '조회수',
  `TITLE` varchar(255) DEFAULT NULL COMMENT '제목',
  `REPLY` char(1) DEFAULT NULL COMMENT '댓글 수',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관 ID',
  `TO_ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '수신기관ID',
  `PUSH_YN` char(1) DEFAULT NULL COMMENT '푸시여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `SORT` decimal(10,0) DEFAULT 0 COMMENT '정렬순서(DEFAULT: 0, faq일경우 적용, 그외 게시판은 0)',
  `PWD` varchar(255) DEFAULT NULL COMMENT '게시글 비밀번호',
  `PINNED_YN` char(1) DEFAULT NULL COMMENT '공지사항 상단 고정 여부',
  PRIMARY KEY (`FORUM_POST_ID`),
  KEY `FORUM_POST_FK` (`TO_ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `FORUM_POST_FK` FOREIGN KEY (`TO_ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='포럼 게시글';

-- dbpoap.forum_post_push definition

CREATE TABLE `forum_post_push` (
  `FORUM_POST_PUSH_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `POST_ID` varchar(36) DEFAULT NULL COMMENT '게시글 ID',
  `TO_ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '수신기관ID',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`FORUM_POST_PUSH_ID`),
  KEY `FORUM_POST_PUSH_FK` (`TO_ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `FORUM_POST_PUSH_FK` FOREIGN KEY (`TO_ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='포럼 게시글';

-- dbpoap.forum_post_reply definition

CREATE TABLE `forum_post_reply` (
  `FORUM_POST_REPLY_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `FORUM_POST_ID` varchar(36) DEFAULT NULL COMMENT '게시글 ID',
  `CONTENT` longtext DEFAULT NULL COMMENT '댓글 내용',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`FORUM_POST_REPLY_ID`),
  KEY `FORUM_POST_REPLY_FK` (`FORUM_POST_ID`) USING BTREE,
  CONSTRAINT `FORUM_POST_REPLY_FK` FOREIGN KEY (`FORUM_POST_ID`) REFERENCES `forum_post` (`FORUM_POST_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='포럼 게시글 댓글';

-- dbpoap.from_os_metrics definition

CREATE TABLE `from_os_metrics` (
  `API_ID` varchar(48) NOT NULL COMMENT 'API ID',
  `APP_KEY` varchar(255) NOT NULL COMMENT '앱 키',
  `POD_ID` varchar(255) NOT NULL COMMENT 'POD ID',
  `TIMESLICE` timestamp NOT NULL COMMENT '시간 구간',
  `API_CODE` varchar(255) DEFAULT NULL COMMENT 'API 코드(수신 서비스 코드)',
  `API_NAME` varchar(255) DEFAULT NULL COMMENT 'API 이름',
  `ORGANIZATION_ID` varchar(255) DEFAULT NULL COMMENT '기관 ID',
  `TARGET_URL` varchar(128) DEFAULT NULL COMMENT 'GW API URI',
  `APP_ID` varchar(255) DEFAULT NULL COMMENT '앱ID',
  `ATTEMPTED_COUNT` decimal(38,0) DEFAULT NULL COMMENT '시도 건수',
  `COMPLETED_COUNT` decimal(38,0) DEFAULT NULL COMMENT '완료 건수',
  `MIN_RUNTIME` decimal(38,0) DEFAULT NULL COMMENT '최소 응답 시간',
  `MAX_RUNTIME` decimal(38,0) DEFAULT NULL COMMENT '최대 응답 시간',
  `AVE_RUNTIME` decimal(38,0) DEFAULT NULL COMMENT '평균 응답 시간',
  PRIMARY KEY (`API_ID`,`APP_KEY`,`POD_ID`,`TIMESLICE`),
  KEY `FROM_OS_METRICS_APIIDX01` (`API_ID`) USING BTREE,
  KEY `FROM_OS_METRICS_APIIDX0102` (`API_NAME`) USING BTREE,
  KEY `FROM_OS_METRICS_APPIDX01` (`APP_ID`) USING BTREE,
  KEY `FROM_OS_METRICS_ORGAPPAPIIDX03` (`ORGANIZATION_ID`,`APP_ID`,`API_ID`) USING BTREE,
  KEY `FROM_OS_METRICS_ORGAPPIDX02` (`ORGANIZATION_ID`,`APP_ID`) USING BTREE,
  KEY `FROM_OS_METRICS_ORGIDX01` (`ORGANIZATION_ID`) USING BTREE,
  KEY `FROM_OS_METRICS_TIMESLICEIDX01` (`TIMESLICE`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='게이트웨이 통계';

-- dbpoap.message_template definition

CREATE TABLE `message_template` (
  `MESSAGE_TEMPLATE_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `NAME` varchar(255) NOT NULL COMMENT '템플릿 명',
  `CODE` varchar(255) DEFAULT NULL COMMENT '코드',
  `DESCRIPTION` varchar(1024) DEFAULT NULL COMMENT '설명',
  `CONTENTS` longtext DEFAULT NULL COMMENT '템플릿 내용',
  `EMAIL_ADDRESS` varchar(255) DEFAULT NULL COMMENT '발송자 이메일',
  `SENDER` varchar(255) DEFAULT NULL COMMENT '발송자',
  `TITLE` varchar(255) DEFAULT NULL COMMENT '제목',
  `TYPE` varchar(10) DEFAULT NULL COMMENT '유형',
  `USE_YN` char(1) DEFAULT NULL COMMENT '사용 여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`MESSAGE_TEMPLATE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='메시지 템플릿';

-- dbpoap.organization_info definition

CREATE TABLE `organization_info` (
  `ORGANIZATION_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `NAME` varchar(50) NOT NULL COMMENT '이름',
  `BRN` varchar(12) DEFAULT NULL COMMENT '사업자 등록번호',
  `STATE` varchar(30) DEFAULT NULL COMMENT '상태',
  `CODE` varchar(16) DEFAULT NULL COMMENT '이용 기관 코드(GW)',
  `BUSINESS_TYPE` varchar(50) DEFAULT NULL COMMENT '사업자 구분',
  `CEO_NAME` varchar(255) DEFAULT NULL COMMENT '대표자명',
  `CORP_NO` varchar(200) DEFAULT NULL COMMENT '법인 등록 번호',
  `TEL` varchar(255) DEFAULT NULL COMMENT '전화번호',
  `SECTOR` varchar(255) DEFAULT NULL COMMENT '업종',
  `ADDRESS` varchar(255) DEFAULT NULL COMMENT '주소',
  `HOMEPAGE` varchar(50) DEFAULT NULL COMMENT '홈페이지 URL',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '설명',
  `ORGANIZATION_TYPE` char(1) DEFAULT NULL COMMENT '기관구분 (P:제공기관 U:이용기관)',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `EMAIL` varchar(256) DEFAULT NULL COMMENT '대표 이메일',
  `OAPI_SYS_DV_CD` varchar(100) DEFAULT NULL COMMENT '오픈API시스템구분코드',
  PRIMARY KEY (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='기관 테이블';

-- dbpoap.organization_info_aud definition

CREATE TABLE `organization_info_aud` (
  `ORGANIZATION_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `REV` decimal(20,0) NOT NULL COMMENT '버전',
  `REVTYPE` char(1) DEFAULT NULL COMMENT '버전타입(C:create, U:update, D:delete)',
  `NAME` varchar(50) NOT NULL COMMENT '이름',
  `BRN` varchar(12) DEFAULT NULL COMMENT '사업자 등록번호',
  `STATE` varchar(30) DEFAULT NULL COMMENT '상태',
  `CODE` varchar(16) DEFAULT NULL COMMENT '이용 기관 코드(GW)',
  `BUSINESS_TYPE` varchar(50) DEFAULT NULL COMMENT '사업자 구분',
  `CEO_NAME` varchar(255) DEFAULT NULL COMMENT '대표자명',
  `CORP_NO` varchar(255) DEFAULT NULL COMMENT '법인 등록 번호',
  `TEL` varchar(255) DEFAULT NULL COMMENT '전화번호',
  `SECTOR` varchar(255) DEFAULT NULL COMMENT '업종',
  `ADDRESS` varchar(255) DEFAULT NULL COMMENT '주소',
  `HOMEPAGE` varchar(50) DEFAULT NULL COMMENT '홈페이지 URL',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '설명',
  `ORGANIZATION_TYPE` char(1) DEFAULT NULL COMMENT '기관구분 (P:제공기관 U:이용기관)',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `EMAIL` varchar(36) DEFAULT NULL COMMENT '대표 이메일',
  `OAPI_SYS_DV_CD` varchar(100) DEFAULT NULL COMMENT '오픈API시스템구분코드',
  PRIMARY KEY (`ORGANIZATION_ID`,`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='기관 임시 테이블';

-- dbpoap.pod_info definition

CREATE TABLE `pod_info` (
  `POD_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `POD_CODE` varchar(50) NOT NULL COMMENT 'POD 코드',
  `POD_DESCRIPTION` varchar(300) DEFAULT NULL COMMENT 'POD 설명',
  `REG_DTTM` timestamp NULL DEFAULT current_timestamp() COMMENT '등록일',
  `BT_CODE` varchar(50) DEFAULT NULL COMMENT 'BT에서 받은 CD',
  `RECORD_STATE` decimal(1,0) DEFAULT NULL COMMENT 'BT에서 받은 useYn',
  `SYSTEM_DIV_CODE` varchar(3) DEFAULT NULL COMMENT '시스템 구분 코드',
  `ETC_DESCRIPTION` varchar(2000) DEFAULT NULL COMMENT '상세 설명',
  PRIMARY KEY (`POD_ID`),
  KEY `POD_INFO_CODE_IDX` (`POD_CODE`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='POD 정보';

-- dbpoap.pod_svr_stat_info definition

CREATE TABLE `pod_svr_stat_info` (
  `POD_SVR_STAT_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT '파드가용상태 ID',
  `POD_ID` varchar(36) NOT NULL COMMENT 'POD ID',
  `SVR_STAT_CD` varchar(10) NOT NULL COMMENT '서버가용구분코드 (01: 정상, 02: 장애, 03: 시스템 점검, 99: 기타)',
  `SVR_STAT_MSG` varchar(2000) DEFAULT NULL COMMENT '서버 상태 메시지',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태 (0: 정상, 9: 삭제)',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '수정자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록자',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정일시',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록일시',
  PRIMARY KEY (`POD_SVR_STAT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='파드가용상태 정보';

-- dbpoap.portal_access_log definition

CREATE TABLE `portal_access_log` (
  `idx` varchar(50) NOT NULL COMMENT 'IDX',
  `PORTAL_TYPE` varchar(50) DEFAULT NULL COMMENT '포탈 타입',
  `PAGE_URL` varchar(50) DEFAULT NULL COMMENT 'PAGE URL',
  `USER_IP` varchar(50) DEFAULT NULL COMMENT '접속IP',
  `USER_KEY` varchar(50) DEFAULT NULL COMMENT '접속KEY',
  `ACCESS_DATE` varchar(50) DEFAULT NULL COMMENT '접근일자',
  `ACCESS_TIME` varchar(50) DEFAULT NULL COMMENT '접근시간',
  PRIMARY KEY (`idx`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='포탈 접근 로그';

-- dbpoap.regular_mgnt_info definition

CREATE TABLE `regular_mgnt_info` (
  `REGULAR_MGNT_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT '정기관리ID',
  `MGNT_NAME` varchar(255) NOT NULL COMMENT '관리 명',
  `MGNT_DETAIL` varchar(4000) DEFAULT NULL COMMENT '관리 상세 내용',
  `START_DATE` varchar(10) NOT NULL COMMENT '시작일',
  `EXPIRE_DATE` varchar(10) NOT NULL COMMENT '만료일',
  `MAIN_USER_ID` varchar(36) NOT NULL COMMENT '주 담당자 ID',
  `SUB_USER1_ID` varchar(36) DEFAULT NULL COMMENT '부 담당자1 ID',
  `SUB_USER2_ID` varchar(36) DEFAULT NULL COMMENT '부 담당자2 ID',
  `SUB_USER3_ID` varchar(36) DEFAULT NULL COMMENT '부 담당자3 ID',
  `SUB_USER4_ID` varchar(36) DEFAULT NULL COMMENT '부 담당자4 ID',
  `NOTIFY_YN` char(1) DEFAULT NULL COMMENT '알림 여부',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '기록 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '등록 사용자 ID',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록 일시',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '수정 사용자 ID',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정일시'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='정기 관리 정보';

-- dbpoap.role_api_permission definition

CREATE TABLE `role_api_permission` (
  `ROLE_CODE` varchar(50) NOT NULL COMMENT '역할 코드',
  `PERMISSION_ID` varchar(100) NOT NULL COMMENT '권한 ID',
  `VIEW_YN` char(1) DEFAULT 'N' COMMENT '조회 여부',
  `CREATE_YN` char(1) DEFAULT 'N' COMMENT '생성 여부',
  `UPDATE_YN` char(1) DEFAULT 'N' COMMENT '수정 여부',
  `DELETE_YN` char(1) DEFAULT 'N' COMMENT '삭제 여부',
  PRIMARY KEY (`ROLE_CODE`,`PERMISSION_ID`),
  CONSTRAINT `ROLE_API_PERMISSION_FK` FOREIGN KEY (`ROLE_CODE`) REFERENCES `role_info` (`ROLE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 역할 권한';

-- dbpoap.role_info definition

CREATE TABLE `role_info` (
  `ROLE_CODE` varchar(50) NOT NULL COMMENT '역할 코드',
  `ROLE_NAME` varchar(100) NOT NULL COMMENT '역할 명',
  `DESCRIPTION` varchar(255) DEFAULT NULL COMMENT '설명',
  `USE_YN` char(1) DEFAULT 'Y' COMMENT '사용 여부',
  `REG_DTTM` timestamp NULL DEFAULT current_timestamp() COMMENT '등록 일시',
  `POD_ID` varchar(50) DEFAULT NULL COMMENT 'POD ID',
  `POD_CODE` varchar(50) DEFAULT NULL COMMENT 'POD 코드',
  `POD_DESCRIPTION` varchar(50) DEFAULT NULL COMMENT 'POD 설명',
  `BT_CODE` decimal(38,0) DEFAULT NULL COMMENT 'BT 코드',
  `RECORD_STATE` decimal(38,0) DEFAULT NULL COMMENT '기록 상태',
  `SYSTEM_DIV_CODE` varchar(50) DEFAULT NULL COMMENT '시스템 구분 코드',
  `ETC_DESCRIPTION` varchar(50) DEFAULT NULL COMMENT '기타 설명',
  PRIMARY KEY (`ROLE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='역할 정보';

-- dbpoap.role_ui_permission definition

CREATE TABLE `role_ui_permission` (
  `ROLE_CODE` varchar(50) NOT NULL COMMENT '역할 코드',
  `MENU_ID` varchar(100) NOT NULL COMMENT '메뉴 ID',
  PRIMARY KEY (`ROLE_CODE`,`MENU_ID`),
  CONSTRAINT `ROLE_UI_PERMISSION_FK` FOREIGN KEY (`ROLE_CODE`) REFERENCES `role_info` (`ROLE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='UI 역할 권한';

-- dbpoap.terms_of_use definition

CREATE TABLE `terms_of_use` (
  `TERMS_OF_USE_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `CONTENT` longtext DEFAULT NULL COMMENT '내용',
  `TERMS_OF_USE` decimal(10,0) DEFAULT NULL COMMENT '활성화 여부',
  `NAME` varchar(255) NOT NULL COMMENT '약관명',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관ID',
  `TYPE` varchar(255) DEFAULT NULL COMMENT '유형(MARKET,ORGANIZATION,USER,AGREEMENT,API,PRIVACY)',
  `RECORD_STATE` decimal(10,0) DEFAULT NULL COMMENT '레코드 상태 (0:정상, 2:삭제)',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `ENABLED` bigint(20) DEFAULT NULL COMMENT '할당량 설정',
  PRIMARY KEY (`TERMS_OF_USE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='약관';

-- dbpoap.transaction_info definition

CREATE TABLE `transaction_info` (
  `TRANSACTION_CODE` varchar(255) NOT NULL COMMENT '거래코드',
  `TRANSACTION_NAME` varchar(200) DEFAULT NULL COMMENT '거래명',
  `TRANSACTION_GRANT` varchar(50) DEFAULT NULL COMMENT '거래권한',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`TRANSACTION_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='포털 거래 정보';

-- dbpoap.transaction_log definition

CREATE TABLE `transaction_log` (
  `TRANSACTION_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `TRANSACTION_CODE` varchar(100) DEFAULT NULL COMMENT '거래코드',
  `ROLE_CODE` varchar(50) DEFAULT NULL COMMENT '권한 코드',
  `PROCESS_STATE` varchar(50) DEFAULT NULL COMMENT '처리 상태',
  `INPUT` longtext DEFAULT NULL COMMENT '입력 내용',
  `OUTPUT` longtext DEFAULT NULL COMMENT '출력 내용',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `TRANSACTION_NAME` varchar(100) DEFAULT NULL COMMENT '거래명',
  `PORTAL_TYPE` varchar(10) DEFAULT NULL COMMENT '포탈 타입',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '이용기관ID',
  `USER_IP` varchar(20) DEFAULT NULL COMMENT '접속IP',
  PRIMARY KEY (`TRANSACTION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API 호출 로깅';

-- dbpoap.ums_history definition

CREATE TABLE `ums_history` (
  `UMS_HISTORY_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'UMS 이력 ID',
  `UMS_HISTORY_TYPE` char(1) NOT NULL COMMENT 'UMS 이력 타입(1.UMS 전송, 2:본인인증요청)',
  `TRSC_DV_CD` char(1) NOT NULL COMMENT '거래구분코드(1:인터페이스의 암호화전화번호 항목으로 전송, 2:BT데이터 변환테이블에 등록된 번호로 전송)',
  `UMS_MSG_DV_CD` char(1) NOT NULL COMMENT 'UMS메시지구분코드(1:SMS, 2:이메일, 3:팩스, K:카카오톡, L:LMS, P:PUSH)',
  `MSG_DV_CD` char(1) NOT NULL COMMENT '메시지구분코드(1:EMAIL, 2:SMS, 3:FAX, 4:기타)',
  `MSG_TITLE` varchar(255) DEFAULT NULL COMMENT '메시지제목',
  `MSG_CTT` longtext DEFAULT NULL COMMENT '메시지내용',
  `MSG_DT` varchar(8) DEFAULT NULL COMMENT '메시지전송일자',
  `TEL_NO_CNT` decimal(10,0) DEFAULT NULL COMMENT '전화번호 개수',
  `CHNL2_TMSG_TRMS_DV_CD` char(2) DEFAULT NULL COMMENT '2채널전문전송구분코드(18: 인증번호 요청 거래, 19: 인증번호 확인 거래)',
  `CHNL2_CERT_NO` varchar(6) DEFAULT NULL COMMENT '2채널인증번호',
  `TRMS_BOD_CTT` varchar(3000) DEFAULT NULL COMMENT '전문개별부내용',
  `RSP_CODE` varchar(9) DEFAULT NULL COMMENT '세부응답코드',
  `RSP_MSG` varchar(450) DEFAULT NULL COMMENT '세부응답메시지',
  `REQ_REASON` varchar(3000) DEFAULT NULL COMMENT '사유',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '등록자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '등록일시',
  `SMS_AUTH_CODE` varchar(8) DEFAULT NULL COMMENT 'SMS 인증번호',
  `TEMPLATE_CODE` varchar(255) DEFAULT NULL COMMENT '인증 용도',
  `EXPIRE_DTTM` timestamp NULL DEFAULT NULL COMMENT '인증 만료 시간 (3분후)',
  `IS_VERIFIED` char(1) DEFAULT 'N' COMMENT '인증 성공 여부',
  PRIMARY KEY (`UMS_HISTORY_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='UMS 메시지 발송 이력';

-- dbpoap.ums_history_telno definition

CREATE TABLE `ums_history_telno` (
  `UMS_HISTORY_TELNO_ID` varchar(36) NOT NULL DEFAULT 'uuid()' COMMENT 'UMS 이력 ID',
  `UMS_HISTORY_ID` varchar(36) NOT NULL COMMENT 'UMS 이력 전화번호 ID',
  `CRYP_TEL_NO` varchar(50) NOT NULL COMMENT '암호화전화번호',
  PRIMARY KEY (`UMS_HISTORY_TELNO_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='UMS 메시지 발송 전화번호';

-- dbpoap.user_info definition

CREATE TABLE `user_info` (
  `USER_ID` varchar(100) NOT NULL DEFAULT 'uuid()' COMMENT 'ID',
  `LOGIN_ID` varchar(100) DEFAULT NULL COMMENT 'LOGIN_ID',
  `EMAIL` varchar(100) DEFAULT NULL COMMENT '이메일',
  `JOB_NAME` varchar(100) DEFAULT NULL COMMENT '직위',
  `USER_TEL` varchar(100) DEFAULT NULL COMMENT '사용자 전화번호',
  `STATE` varchar(100) DEFAULT NULL COMMENT '사용자 상태 코드(Y:활성,N:비활성,W:승인대기,B:휴면)',
  `ORGANIZATION_ID` varchar(100) DEFAULT NULL COMMENT '기관 ID',
  `PHONE_NO` varchar(100) DEFAULT NULL COMMENT '휴대폰 번호',
  `USER_NAME` varchar(100) DEFAULT NULL COMMENT '사용자명',
  `ROLE_CODE` varchar(100) DEFAULT NULL COMMENT '사용자역할',
  `LOGIN_LOCK` varchar(100) DEFAULT NULL COMMENT '로그인 잠금 여부',
  `LOGIN_LOCK_TIME` varchar(100) DEFAULT NULL COMMENT '로그인 잠긴 시간',
  `LOGIN_FAIL_COUNT` varchar(100) DEFAULT '0' COMMENT '로그인 실패 횟수',
  `LOGIN_DTTM` varchar(100) DEFAULT NULL COMMENT '최종 로그인 일자',
  `TMP_PWD_YN` varchar(100) DEFAULT NULL COMMENT '임시 비밀번호 발급 여부',
  `PWD_CHANGE_DT` varchar(100) DEFAULT NULL COMMENT '비밀번호 변경일',
  `USER_PWD` varchar(100) NOT NULL COMMENT '사용자 비밀번호',
  `TMP_PWD` varchar(100) DEFAULT NULL COMMENT '임시 비밀번호',
  `RECORD_STATE` varchar(100) DEFAULT '0' COMMENT '레코드 상태',
  `REG_USER` varchar(100) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` varchar(100) DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(100) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` varchar(100) DEFAULT NULL COMMENT '최종 수정일',
  `USE_PRIVACY_AGREE_YN` varchar(100) DEFAULT NULL COMMENT '개인정보이용 동의 여부',
  `USE_PRIVACY_AGREE_DTTM` varchar(100) DEFAULT NULL COMMENT '개인정보이용 동의일',
  `STAFF_YN` varchar(100) DEFAULT NULL COMMENT '대외팀 직원 여부',
  PRIMARY KEY (`USER_ID`),
  KEY `USER_INFO_FK` (`ORGANIZATION_ID`) USING BTREE,
  CONSTRAINT `USER_INFO_FK` FOREIGN KEY (`ORGANIZATION_ID`) REFERENCES `organization_info` (`ORGANIZATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='사용자 임시 테이블';

-- dbpoap.user_info_aud definition

CREATE TABLE `user_info_aud` (
  `USER_ID` varchar(36) NOT NULL COMMENT 'ID',
  `REV` decimal(20,0) NOT NULL COMMENT '버전',
  `REVTYPE` char(20) DEFAULT NULL COMMENT '버전타입(C:create, U:update, D:delete)',
  `LOGIN_ID` varchar(50) DEFAULT NULL COMMENT '로그인 아이디',
  `EMAIL` varchar(256) DEFAULT NULL COMMENT '이메일',
  `JOB_NAME` varchar(255) DEFAULT NULL COMMENT '직위',
  `USER_TEL` varchar(255) DEFAULT NULL COMMENT '사용자 전화번호',
  `STATE` varchar(255) DEFAULT NULL COMMENT '사용자 상태 코드',
  `ORGANIZATION_ID` varchar(36) DEFAULT NULL COMMENT '기관 ID',
  `PHONE_NO` varchar(15) DEFAULT NULL COMMENT '휴대폰 번호',
  `USER_NAME` varchar(60) DEFAULT NULL COMMENT '사용자명',
  `ROLE_CODE` varchar(30) DEFAULT NULL COMMENT '사용자역할',
  `LOGIN_LOCK` varchar(50) DEFAULT NULL COMMENT '로그인 잠금 여부',
  `LOGIN_LOCK_TIME` varchar(50) DEFAULT NULL COMMENT '로그인 잠긴 시간',
  `LOGIN_FAIL_COUNT` decimal(38,0) DEFAULT 0 COMMENT '로그인 실패 횟수',
  `LOGIN_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 로그인 일자',
  `TMP_PWD_YN` varchar(50) DEFAULT NULL COMMENT '임시 비밀번호 발급 여부',
  `PWD_CHANGE_DT` timestamp NULL DEFAULT NULL COMMENT '비밀번호 변경일',
  `USER_PWD` varchar(256) DEFAULT NULL COMMENT '사용자 비밀번호',
  `TMP_PWD` varchar(256) DEFAULT NULL COMMENT '임시 비밀번호',
  `RECORD_STATE` decimal(1,0) DEFAULT 0 COMMENT '레코드 상태',
  `REG_USER` varchar(36) DEFAULT NULL COMMENT '생성자',
  `REG_DTTM` timestamp NULL DEFAULT NULL COMMENT '생성일',
  `MOD_USER` varchar(36) DEFAULT NULL COMMENT '최종 수정자',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '최종 수정일',
  PRIMARY KEY (`USER_ID`,`REV`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='사용자 임시 테이블';