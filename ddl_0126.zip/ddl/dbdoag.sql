-- dbpoag.oauth2_authorization definition

CREATE TABLE `oauth2_authorization` (
  `ID` varchar(200) NOT NULL COMMENT 'ID',
  `REGISTERED_CLIENT_ID` varchar(200) NOT NULL COMMENT '등록된 클라이언트 ID',
  `PRINCIPAL_NAME` varchar(200) NOT NULL COMMENT '주체 이름',
  `AUTHORIZATION_GRANT_TYPE` varchar(200) NOT NULL COMMENT '권한 부여 유형',
  `AUTHORIZED_SCOPES` varchar(1000) DEFAULT NULL COMMENT '승인된 스코프',
  `ATTRIBUTES` longtext DEFAULT NULL COMMENT '속성',
  `STATE` varchar(500) DEFAULT NULL COMMENT '상태',
  `AUTHORIZATION_CODE_VALUE` longtext DEFAULT NULL COMMENT '권한 코드 값',
  `AUTHORIZATION_CODE_ISSUED_AT` timestamp NULL DEFAULT NULL COMMENT '권한 코드 발급 일시',
  `AUTHORIZATION_CODE_EXPIRES_AT` timestamp NULL DEFAULT NULL COMMENT '권한 코드 만료 일시',
  `AUTHORIZATION_CODE_METADATA` longtext DEFAULT NULL COMMENT '권한 코드 메타데이타',
  `ACCESS_TOKEN_ISSUED_AT` timestamp NULL DEFAULT str_to_date('2000-01-01 12:00:00','%Y-%m-%d %H:%i:%s') COMMENT '접근 토큰 발급 일시',
  `ACCESS_TOKEN_EXPIRES_AT` timestamp NULL DEFAULT str_to_date('2000-01-01 12:00:00','%Y-%m-%d %H:%i:%s') COMMENT '접근 토큰 만료 일시',
  `ACCESS_TOKEN_METADATA` varchar(2000) DEFAULT NULL COMMENT '접근 토큰 메타데이타',
  `ACCESS_TOKEN_TYPE` varchar(200) DEFAULT NULL COMMENT '접근 토큰 유형',
  `ACCESS_TOKEN_SCOPES` varchar(1000) DEFAULT NULL COMMENT '접근 토큰 스코프',
  `OIDC_ID_TOKEN_VALUE` longtext DEFAULT NULL COMMENT 'OIDC ID 토큰 값',
  `OIDC_ID_TOKEN_ISSUED_AT` timestamp NULL DEFAULT NULL COMMENT 'OIDC ID 토큰 발급 일시',
  `OIDC_ID_TOKEN_EXPIRES_AT` timestamp NULL DEFAULT NULL COMMENT 'OIDC ID 만료 일시',
  `OIDC_ID_TOKEN_METADATA` longtext DEFAULT NULL COMMENT 'OIDC ID 메타데이타',
  `REFRESH_TOKEN_VALUE` longtext DEFAULT NULL COMMENT '재발급 토큰 값',
  `REFRESH_TOKEN_ISSUED_AT` timestamp NULL DEFAULT NULL COMMENT '재발급 토큰 발급 일시',
  `REFRESH_TOKEN_EXPIRES_AT` timestamp NULL DEFAULT NULL COMMENT '재발급 토큰 만료 일시',
  `REFRESH_TOKEN_METADATA` longtext DEFAULT NULL COMMENT '재발급 토큰 메타데이타',
  `USER_CODE_VALUE` longtext DEFAULT NULL COMMENT '사용자 코드 값',
  `USER_CODE_ISSUED_AT` timestamp NULL DEFAULT NULL COMMENT '사용자 코드 발급 일시',
  `USER_CODE_EXPIRES_AT` timestamp NULL DEFAULT NULL COMMENT '사용자 코드 만료 일시',
  `USER_CODE_METADATA` longtext DEFAULT NULL COMMENT '사용자 코드 메타데이타',
  `DEVICE_CODE_VALUE` longtext DEFAULT NULL COMMENT '장치 코드값',
  `DEVICE_CODE_ISSUED_AT` timestamp NULL DEFAULT NULL COMMENT '장치 코드 발급 일시',
  `DEVICE_CODE_EXPIRES_AT` timestamp NULL DEFAULT NULL COMMENT '장치 코드 만료 일시',
  `DEVICE_CODE_METADATA` longtext DEFAULT NULL COMMENT '장치 코드 메타데이타',
  `ACCESS_TOKEN_VALUE` longtext DEFAULT NULL COMMENT '접근 토큰 값',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정 일시'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='OAUTH2 권한 부여';


-- dbpoag.oauth2_registered_client definition

CREATE TABLE `oauth2_registered_client` (
  `ID` varchar(200) NOT NULL COMMENT 'ID',
  `CLIENT_ID` varchar(200) NOT NULL COMMENT '클라이언트 ID',
  `CLIENT_ID_ISSUED_AT` timestamp NOT NULL COMMENT '클라이언트 ID 발급 일시',
  `CLIENT_SECRET` varchar(300) DEFAULT NULL COMMENT '클라이언트 보안 비밀',
  `CLIENT_SECRET_EXPIRES_AT` datetime NOT NULL DEFAULT str_to_date('2000-01-01 12:00:00','%Y-%m-%d %H:%i:%s') COMMENT '클라이언트 보안 비밀 만료 일시',
  `CLIENT_NAME` varchar(100) NOT NULL COMMENT '클라이언트 이름',
  `CLIENT_AUTHENTICATION_METHODS` varchar(1000) NOT NULL COMMENT '클라이언트 인증 방식',
  `AUTHORIZATION_GRANT_TYPES` varchar(1000) NOT NULL COMMENT '권한 부여 유형',
  `REDIRECT_URIS` varchar(1000) DEFAULT NULL COMMENT '리다이렉트 URL',
  `POST_LOGOUT_REDIRECT_URIS` varchar(1000) DEFAULT NULL COMMENT '로그아웃 후 리다이렉트 URL',
  `SCOPES` varchar(1000) NOT NULL COMMENT '스코프',
  `CLIENT_SETTINGS` varchar(2000) NOT NULL COMMENT '클라이언트 설정',
  `TOKEN_SETTINGS` varchar(2000) NOT NULL COMMENT '토큰 설정',
  `REQUEST_TYPE` varchar(10) DEFAULT NULL COMMENT '요청 유형',
  `ORG_CODE` varchar(20) DEFAULT NULL COMMENT '기관 코드',
  `MOD_DTTM` timestamp NULL DEFAULT NULL COMMENT '수정 일시',
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='OAuth2 등록 클라이언트';


-- dbpoag.oauth_access_token definition

CREATE TABLE `oauth_access_token` (
  `AUTHENTICATION_ID` varchar(256) DEFAULT NULL COMMENT '인증 ID',
  `TOKEN_ID` varchar(256) DEFAULT NULL COMMENT '토큰 ID',
  `TOKEN_VALUE` varchar(2500) DEFAULT NULL COMMENT '토큰 값',
  `USER_NAME` varchar(256) DEFAULT NULL COMMENT '사용자 이름',
  `CLIENT_ID` varchar(256) DEFAULT NULL COMMENT '클라이언트 ID',
  `REFRESH_TOKEN` varchar(256) DEFAULT NULL COMMENT '재발급 토큰',
  `REFRESH_TOKEN_VALUE` varchar(2500) DEFAULT NULL COMMENT '재발급 토큰 값',
  `EXPIRE_DATE` date DEFAULT NULL COMMENT '만료일',
  `REG_DATE` date DEFAULT current_timestamp() COMMENT '등록일',
  `REVOKED` decimal(10,0) DEFAULT 0 COMMENT '폐기 여부',
  `REVOKE_DATE` date DEFAULT NULL COMMENT '폐기일',
  `REFRESHED` decimal(10,0) DEFAULT 0 COMMENT '갱신 여부',
  `ACCESS_TOKEN_ID` decimal(24,0) NOT NULL COMMENT '접근 토큰 ID',
  `AUTHENTICATION` blob DEFAULT NULL COMMENT '인증 정보',
  `REVOKE_TYPE` varchar(2) DEFAULT NULL COMMENT '폐기 유형'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='OAUTH 접근 토큰';